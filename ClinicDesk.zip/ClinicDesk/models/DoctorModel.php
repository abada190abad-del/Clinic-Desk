<?php

require_once __DIR__ . '/BaseModel.php';

class DoctorModel extends BaseModel
{
    public function findById(int $doctorId): ?array
    {
        $sql = 'SELECT d.*, u.name AS user_name, u.email, u.phone, u.avatar, u.is_active, s.name AS specialization_name
                FROM doctors d
                JOIN users u ON u.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                WHERE d.id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$doctorId]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function findByUserId(int $userId): ?array
    {
        $sql = 'SELECT d.*, u.name AS user_name, u.email, u.phone, u.avatar, u.is_active, s.name AS specialization_name
                FROM doctors d
                JOIN users u ON u.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                WHERE d.user_id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$userId]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function getAll(): array
    {
        $sql = 'SELECT d.id, d.user_id, d.consultation_fee, d.available_days, u.name AS doctor_name, s.name AS specialization_name
                FROM doctors d
                JOIN users u ON u.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                WHERE u.is_active = 1
                ORDER BY u.name ASC';
        $res = $this->execute($sql);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function countAll(): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM doctors';
        $res = $this->execute($sql);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getAllPaginated(int $page): array
    {
        $per = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $per;
        $sql = 'SELECT d.*, u.name AS user_name, u.email, u.phone, s.name AS specialization_name
                FROM doctors d
                JOIN users u ON u.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                ORDER BY d.id DESC
                LIMIT ? OFFSET ?';
        $res = $this->execute($sql, 'ii', [$per, $offset]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO doctors (user_id, specialization_id, bio, consultation_fee, available_days, photo)
                VALUES (?,?,?,?,?,?)';
        $this->execute($sql, 'iisdss', [
            (int) $data['user_id'],
            (int) $data['specialization_id'],
            $data['bio'] ?? null,
            (float) $data['consultation_fee'],
            $data['available_days'],
            $data['photo'] ?? null,
        ]);
        return $this->db->lastInsertId();
    }

    public function update(int $doctorId, array $data): bool
    {
        $sql = 'UPDATE doctors SET specialization_id = ?, bio = ?, consultation_fee = ?, available_days = ?, photo = ?
                WHERE id = ?';
        $ok = $this->execute($sql, 'isdssi', [
            (int) $data['specialization_id'],
            $data['bio'] ?? null,
            (float) $data['consultation_fee'],
            $data['available_days'],
            $data['photo'] ?? null,
            $doctorId,
        ]);
        return $ok !== false;
    }

    public function getAvailableDays(int $doctorId): array
    {
        $d = $this->findById($doctorId);
        if ($d === null) {
            return [];
        }
        $parts = explode(',', (string) $d['available_days']);
        $out = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p !== '') {
                $out[] = $p;
            }
        }
        return $out;
    }
}
