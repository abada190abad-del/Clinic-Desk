<?php

require_once __DIR__ . '/BaseModel.php';

class SpecializationModel extends BaseModel
{
    public function getAll(): array
    {
        $sql = 'SELECT * FROM specializations ORDER BY name ASC';
        $res = $this->execute($sql);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function findById(int $id): ?array
    {
        $sql = 'SELECT * FROM specializations WHERE id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$id]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function create(string $name): int
    {
        $sql = 'INSERT INTO specializations (name) VALUES (?)';
        $this->execute($sql, 's', [$name]);
        return $this->db->lastInsertId();
    }

    public function delete(int $id): bool
    {
        $sql = 'DELETE FROM specializations WHERE id = ?';
        $ok = $this->execute($sql, 'i', [$id]);
        return $ok !== false;
    }

    public function countDoctors(int $specId): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM doctors WHERE specialization_id = ?';
        $res = $this->execute($sql, 'i', [$specId]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function isSafeToDelete(int $id): bool
    {
        return $this->countDoctors($id) === 0;
    }
}
