<?php

require_once __DIR__ . '/BaseModel.php';

class UserModel extends BaseModel
{
    public function findById(int $id): ?array
    {
        $sql = 'SELECT * FROM users WHERE id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$id]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function findByEmail(string $email): ?array
    {
        $sql = 'SELECT * FROM users WHERE email = ? LIMIT 1';
        $res = $this->execute($sql, 's', [$email]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO users (name, email, password, role, phone, first_login) VALUES (?,?,?,?,?,?)';
        $first = isset($data['first_login']) ? (int) $data['first_login'] : 1;
        $this->execute($sql, 'sssssi', [
            $data['name'],
            $data['email'],
            $data['password'],
            $data['role'],
            $data['phone'] ?? null,
            $first,
        ]);
        return $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $sql = 'UPDATE users SET name = ?, phone = ?, avatar = ? WHERE id = ?';
        $ok = $this->execute($sql, 'sssi', [
            $data['name'],
            $data['phone'] ?? null,
            $data['avatar'] ?? null,
            $id,
        ]);
        return $ok !== false;
    }

    public function updatePassword(int $id, string $newHash): bool
    {
        $sql = 'UPDATE users SET password = ? WHERE id = ?';
        $ok = $this->execute($sql, 'si', [$newHash, $id]);
        return $ok !== false;
    }

    public function setFirstLogin(int $id, int $flag): bool
    {
        $sql = 'UPDATE users SET first_login = ? WHERE id = ?';
        $ok = $this->execute($sql, 'ii', [$flag, $id]);
        return $ok !== false;
    }

    public function updateActive(int $id, int $isActive): bool
    {
        $sql = 'UPDATE users SET is_active = ? WHERE id = ?';
        $ok = $this->execute($sql, 'ii', [$isActive, $id]);
        return $ok !== false;
    }

    public function toggleActive(int $id): bool
    {
        $u = $this->findById($id);
        if ($u === null) {
            return false;
        }
        $next = ((int) $u['is_active'] === 1) ? 0 : 1;
        return $this->updateActive($id, $next);
    }

    public function countAll(string $role = '', string $search = ''): int
    {
        $conditions = [];
        $types = '';
        $params = [];

        if ($role !== '') {
            $conditions[] = 'role = ?';
            $types .= 's';
            $params[] = $role;
        }
        if ($search !== '') {
            $conditions[] = '(name LIKE ? OR email LIKE ?)';
            $types .= 'ss';
            $like = '%' . $search . '%';
            $params[] = $like;
            $params[] = $like;
        }

        $where = count($conditions) ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        $sql = 'SELECT COUNT(*) AS c FROM users ' . $where;
        $res = $this->execute($sql, $types, $params);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getAllPaginated(int $page, string $role = '', string $search = ''): array
    {
        $per = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $per;

        $conditions = [];
        $types = '';
        $params = [];

        if ($role !== '') {
            $conditions[] = 'role = ?';
            $types .= 's';
            $params[] = $role;
        }
        if ($search !== '') {
            $conditions[] = '(name LIKE ? OR email LIKE ?)';
            $types .= 'ss';
            $like = '%' . $search . '%';
            $params[] = $like;
            $params[] = $like;
        }

        $where = count($conditions) ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        $sql = 'SELECT * FROM users ' . $where . ' ORDER BY id DESC LIMIT ? OFFSET ?';
        $types .= 'ii';
        $params[] = $per;
        $params[] = $offset;

        $res = $this->execute($sql, $types, $params);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function statsByRole(): array
    {
        $sql = 'SELECT role, COUNT(*) AS total FROM users GROUP BY role';
        $res = $this->execute($sql);
        if (!$res) {
            return [];
        }
        $out = [];
        while ($row = $res->fetch_assoc()) {
            $out[] = $row;
        }
        return $out;
    }
}
