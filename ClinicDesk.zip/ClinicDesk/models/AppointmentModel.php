<?php

require_once __DIR__ . '/BaseModel.php';

class AppointmentModel extends BaseModel
{
    public function book(array $data): bool
    {
        $sql = 'INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, status, reason)
                VALUES (?,?,?,?,?,?)';
        try {
            $ok = $this->execute(
                $sql,
                'iissss',
                [
                    (int) $data['patient_id'],
                    (int) $data['doctor_id'],
                    $data['appt_date'],
                    $data['appt_time'],
                    $data['status'] ?? 'pending',
                    $data['reason'] ?? null,
                ]
            );
            return $ok !== false;
        } catch (Throwable $e) {
            return false;
        }
    }

    public function hasConflict(int $doctorId, string $date, string $time): bool
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments WHERE doctor_id = ? AND appt_date = ? AND appt_time = ?';
        $res = $this->execute($sql, 'iss', [$doctorId, $date, $time]);
        if (!$res) {
            return true;
        }
        $row = $res->fetch_assoc();
        return ((int) ($row['c'] ?? 0)) > 0;
    }

    private function buildFilters(string $scope, int $scopeId, array $filters, bool $forCount): array
    {
        $conditions = [];
        $types = '';
        $params = [];

        if ($scope === 'patient') {
            $conditions[] = 'a.patient_id = ?';
            $types .= 'i';
            $params[] = $scopeId;
        } elseif ($scope === 'doctor') {
            $conditions[] = 'a.doctor_id = ?';
            $types .= 'i';
            $params[] = $scopeId;
        }

        if (!empty($filters['status'])) {
            $conditions[] = 'a.status = ?';
            $types .= 's';
            $params[] = $filters['status'];
        }
        if (!empty($filters['date_from'])) {
            $conditions[] = 'a.appt_date >= ?';
            $types .= 's';
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $conditions[] = 'a.appt_date <= ?';
            $types .= 's';
            $params[] = $filters['date_to'];
        }

        if ($scope === 'admin') {
            if (!empty($filters['doctor_id'])) {
                $conditions[] = 'a.doctor_id = ?';
                $types .= 'i';
                $params[] = (int) $filters['doctor_id'];
            }
            if (!empty($filters['patient_search'])) {
                $conditions[] = 'pu.name LIKE ?';
                $types .= 's';
                $params[] = '%' . $filters['patient_search'] . '%';
            }
        }

        return [$conditions, $types, $params];
    }

    public function countFiltered(string $scope, int $scopeId, array $filters): int
    {
        [$conditions, $types, $params] = $this->buildFilters($scope, $scopeId, $filters, true);
        $where = count($conditions) ? ('WHERE ' . implode(' AND ', $conditions)) : '';

        $joins = 'FROM appointments a
                  JOIN users pu ON pu.id = a.patient_id
                  JOIN doctors d ON d.id = a.doctor_id
                  JOIN users du ON du.id = d.user_id';

        $sql = 'SELECT COUNT(*) AS c ' . $joins . ' ' . $where;
        $res = $this->execute($sql, $types, $params);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getByPatient(int $patientId, int $page, array $filters): array
    {
        return $this->fetchList('patient', $patientId, $page, $filters);
    }

    public function getByDoctor(int $doctorId, int $page, array $filters): array
    {
        return $this->fetchList('doctor', $doctorId, $page, $filters);
    }

    public function getAll(int $page, array $filters): array
    {
        return $this->fetchList('admin', 0, $page, $filters);
    }

    private function fetchList(string $scope, int $scopeId, int $page, array $filters): array
    {
        [$conditions, $types, $params] = $this->buildFilters($scope, $scopeId, $filters, false);
        $where = count($conditions) ? ('WHERE ' . implode(' AND ', $conditions)) : '';

        $per = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $per;

        $sql = 'SELECT a.*, pu.name AS patient_name, du.name AS doctor_name, s.name AS specialization_name, pr.id AS prescription_id
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                LEFT JOIN prescriptions pr ON pr.appointment_id = a.id
                ' . $where . '
                ORDER BY a.appt_date DESC, a.appt_time DESC
                LIMIT ? OFFSET ?';

        $types2 = $types . 'ii';
        $params2 = $params;
        $params2[] = $per;
        $params2[] = $offset;

        $res = $this->execute($sql, $types2, $params2);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function updateStatus(int $id, string $status, string $notes = ''): bool
    {
        if ($notes !== '') {
            $sql = 'UPDATE appointments SET status = ?, doctor_notes = ? WHERE id = ?';
            $ok = $this->execute($sql, 'ssi', [$status, $notes, $id]);
        } else {
            $sql = 'UPDATE appointments SET status = ? WHERE id = ?';
            $ok = $this->execute($sql, 'si', [$status, $id]);
        }
        return $ok !== false;
    }

    public function updateDoctorNotes(int $id, string $notes): bool
    {
        $sql = 'UPDATE appointments SET doctor_notes = ? WHERE id = ?';
        $ok = $this->execute($sql, 'si', [$notes, $id]);
        return $ok !== false;
    }

    public function findById(int $id): ?array
    {
        $sql = 'SELECT a.*, pu.name AS patient_name, pu.email AS patient_email,
                       du.name AS doctor_name, d.id AS doctor_table_id, s.name AS specialization_name
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                WHERE a.id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$id]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function getTodayForDoctor(int $doctorId): array
    {
        $sql = 'SELECT a.*, pu.name AS patient_name
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                WHERE a.doctor_id = ? AND a.appt_date = CURDATE()
                ORDER BY a.appt_time ASC';
        $res = $this->execute($sql, 'i', [$doctorId]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function getRecentForAdmin(int $limit = 5): array
    {
        $sql = 'SELECT a.*, pu.name AS patient_name, du.name AS doctor_name
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                ORDER BY a.created_at DESC
                LIMIT ?';
        $res = $this->execute($sql, 'i', [$limit]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function countTodayAll(): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments WHERE appt_date = CURDATE()';
        $res = $this->execute($sql);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function countThisWeekByStatus(): array
    {
        $sql = 'SELECT status, COUNT(*) AS total
                FROM appointments
                WHERE YEARWEEK(appt_date, 1) = YEARWEEK(CURDATE(), 1)
                GROUP BY status';
        $res = $this->execute($sql);
        if (!$res) {
            return [];
        }
        $out = [];
        while ($row = $res->fetch_assoc()) {
            $out[] = $row;
        }
        return $out;
    }

    public function countThisMonthForDoctor(int $doctorId): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments
                WHERE doctor_id = ? AND YEAR(appt_date) = YEAR(CURDATE()) AND MONTH(appt_date) = MONTH(CURDATE())';
        $res = $this->execute($sql, 'i', [$doctorId]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function countByStatusForDoctorMonth(int $doctorId, string $status): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments
                WHERE doctor_id = ? AND status = ?
                AND YEAR(appt_date) = YEAR(CURDATE()) AND MONTH(appt_date) = MONTH(CURDATE())';
        $res = $this->execute($sql, 'is', [$doctorId, $status]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getNextForDoctor(int $doctorId, int $limit = 5): array
    {
        $sql = 'SELECT a.*, pu.name AS patient_name
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                WHERE a.doctor_id = ?
                  AND (a.appt_date > CURDATE() OR (a.appt_date = CURDATE() AND a.appt_time >= CURTIME()))
                ORDER BY a.appt_date ASC, a.appt_time ASC
                LIMIT ?';
        $res = $this->execute($sql, 'ii', [$doctorId, $limit]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function countPatientActive(int $patientId): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments
                WHERE patient_id = ? AND status IN ("pending","confirmed")';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getPatientActiveList(int $patientId): array
    {
        $sql = 'SELECT a.*, du.name AS doctor_name
                FROM appointments a
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                WHERE a.patient_id = ? AND a.status IN ("pending","confirmed")
                ORDER BY a.appt_date ASC, a.appt_time ASC';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }

    public function countPatientCompleted(int $patientId): int
    {
        $sql = 'SELECT COUNT(*) AS c FROM appointments WHERE patient_id = ? AND status = "completed"';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getPatientNextUpcoming(int $patientId): ?array
    {
        $sql = 'SELECT a.*, du.name AS doctor_name, s.name AS specialization_name
                FROM appointments a
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                WHERE a.patient_id = ? AND a.status IN ("pending","confirmed")
                  AND (a.appt_date > CURDATE() OR (a.appt_date = CURDATE() AND a.appt_time >= CURTIME()))
                ORDER BY a.appt_date ASC, a.appt_time ASC
                LIMIT 1';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function countPrescriptionsForPatient(int $patientId): int
    {
        $sql = 'SELECT COUNT(*) AS c
                FROM prescriptions p
                JOIN appointments a ON a.id = p.appointment_id
                WHERE a.patient_id = ?';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res) {
            return 0;
        }
        $row = $res->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    }

    public function getForReport(string $dateFrom, string $dateTo, ?int $doctorId, string $status, string $patientSearch = ''): array
    {
        $conditions = ['a.appt_date >= ?', 'a.appt_date <= ?'];
        $types = 'ss';
        $params = [$dateFrom, $dateTo];

        if ($doctorId !== null && $doctorId > 0) {
            $conditions[] = 'a.doctor_id = ?';
            $types .= 'i';
            $params[] = $doctorId;
        }
        if ($status !== '') {
            $conditions[] = 'a.status = ?';
            $types .= 's';
            $params[] = $status;
        }
        if ($patientSearch !== '') {
            $conditions[] = 'pu.name LIKE ?';
            $types .= 's';
            $params[] = '%' . $patientSearch . '%';
        }

        $where = 'WHERE ' . implode(' AND ', $conditions);
        $sql = 'SELECT a.*, pu.name AS patient_name, du.name AS doctor_name, s.name AS specialization_name
                FROM appointments a
                JOIN users pu ON pu.id = a.patient_id
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                JOIN specializations s ON s.id = d.specialization_id
                ' . $where . '
                ORDER BY a.appt_date ASC, a.appt_time ASC';

        $res = $this->execute($sql, $types, $params);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
}
