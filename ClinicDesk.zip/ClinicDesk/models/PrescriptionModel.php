<?php

require_once __DIR__ . '/BaseModel.php';

class PrescriptionModel extends BaseModel
{
    public function findByAppointmentId(int $apptId): ?array
    {
        $sql = 'SELECT * FROM prescriptions WHERE appointment_id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$apptId]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function findById(int $id): ?array
    {
        $sql = 'SELECT * FROM prescriptions WHERE id = ? LIMIT 1';
        $res = $this->execute($sql, 'i', [$id]);
        if (!$res || $res->num_rows === 0) {
            return null;
        }
        return $res->fetch_assoc();
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO prescriptions (appointment_id, diagnosis, medications, notes, file_path)
                VALUES (?,?,?,?,?)';
        $this->execute(
            $sql,
            'issss',
            [
                (int) $data['appointment_id'],
                $data['diagnosis'],
                $data['medications'],
                $data['notes'] ?? null,
                $data['file_path'] ?? null,
            ]
        );
        return $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $sql = 'UPDATE prescriptions SET diagnosis = ?, medications = ?, notes = ?, file_path = ? WHERE id = ?';
        $ok = $this->execute($sql, 'ssssi', [
            $data['diagnosis'],
            $data['medications'],
            $data['notes'] ?? null,
            $data['file_path'] ?? null,
            $id,
        ]);
        return $ok !== false;
    }

    public function getByPatient(int $patientId): array
    {
        $sql = 'SELECT p.*, a.appt_date, a.appt_time, du.name AS doctor_name
                FROM prescriptions p
                JOIN appointments a ON a.id = p.appointment_id
                JOIN doctors d ON d.id = a.doctor_id
                JOIN users du ON du.id = d.user_id
                WHERE a.patient_id = ?
                ORDER BY p.created_at DESC';
        $res = $this->execute($sql, 'i', [$patientId]);
        if (!$res) {
            return [];
        }
        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
}
