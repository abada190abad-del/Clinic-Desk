<?php

class Paginator
{
    private int $totalItems;
    private int $perPage;
    private int $currentPage;

    public function __construct(int $totalItems, int $perPage, int $currentPage)
    {
        $this->totalItems = max(0, $totalItems);
        $this->perPage = max(1, $perPage);

        $tp = 1;
        if ($this->totalItems > 0) {
            $tp = (int) ceil($this->totalItems / $this->perPage);
            if ($tp < 1) {
                $tp = 1;
            }
        }

        $this->currentPage = max(1, $currentPage);
        if ($this->currentPage > $tp) {
            $this->currentPage = $tp;
        }
    }

    public function offset(): int
    {
        return ($this->currentPage - 1) * $this->perPage;
    }

    public function totalPages(): int
    {
        if ($this->totalItems === 0) {
            return 1;
        }
        $tp = (int) ceil($this->totalItems / $this->perPage);
        return max(1, $tp);
    }

    public function hasPrev(): bool
    {
        return $this->currentPage > 1;
    }

    public function hasNext(): bool
    {
        return $this->currentPage < $this->totalPages();
    }

    public function currentPage(): int
    {
        return $this->currentPage;
    }

    public function perPage(): int
    {
        return $this->perPage;
    }
}
