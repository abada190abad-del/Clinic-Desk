<?php

class Auth
{
    public static function login(array $user): void
    {
        $_SESSION['user'] = [
            'id' => (int) $user['id'],
            'name' => $user['name'],
            'role' => $user['role'],
            'first_login' => (int) ($user['first_login'] ?? 0),
        ];
        session_regenerate_id(true);
    }

    public static function logout(): void
    {
        session_unset();
        session_destroy();
        redirect('index.php?page=auth&action=login');
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']['id']);
    }

    public static function currentUser(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function role(): string
    {
        return $_SESSION['user']['role'] ?? '';
    }

    public static function id(): int
    {
        return (int) ($_SESSION['user']['id'] ?? 0);
    }

    public static function requireRole(string ...$roles): void
    {
        if (!self::check()) {
            redirect('index.php?page=auth&action=login');
        }
        if (count($roles) === 0) {
            return;
        }
        $r = self::role();
        if (!in_array($r, $roles, true)) {
            redirect('index.php?page=errors&action=forbidden');
        }
    }
}
