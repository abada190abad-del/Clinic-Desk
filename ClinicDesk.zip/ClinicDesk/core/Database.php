<?php

class Database
{
    private static ?Database $instance = null;
    private ?mysqli $conn = null;

    private function __construct()
    {
        // Connect only on first use so pages like login can load if DB is not ready yet.
    }

    private function getConn(): mysqli
    {
        if ($this->conn === null) {
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            try {
                $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                $this->conn->set_charset('utf8mb4');
            } catch (Throwable $e) {
                throw new RuntimeException('Could not connect to the database.');
            }
        }
        return $this->conn;
    }

    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function query(string $sql, string $types = '', array $params = [])
    {
        $conn = $this->getConn();
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            return false;
        }

        if ($types !== '' && count($params) > 0) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();

        if ($stmt->field_count > 0) {
            $result = $stmt->get_result();
            $stmt->close();
            return $result;
        }

        $ok = true;
        $stmt->close();
        return $ok;
    }

    public function lastInsertId(): int
    {
        return (int) $this->getConn()->insert_id;
    }

    private function __clone()
    {
    }

    public function __wakeup()
    {
        throw new RuntimeException('Cannot unserialize singleton.');
    }
}
