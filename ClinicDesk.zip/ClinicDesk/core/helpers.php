<?php

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function sanitize(string $value): string
{
    return trim($value);
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function formatDate(?string $date): string
{
    if ($date === null || $date === '') {
        return '';
    }
    $t = strtotime($date);
    if ($t === false) {
        return '';
    }
    return date('Y-m-d', $t);
}

function formatTime(?string $time): string
{
    if ($time === null || $time === '') {
        return '';
    }
    $t = strtotime($time);
    if ($t === false) {
        return $time;
    }
    return date('H:i', $t);
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function appt_time_slots(): array
{
    $slots = [];
    $start = strtotime('09:00');
    $end = strtotime('16:00');
    for ($t = $start; $t <= $end; $t += 1800) {
        $slots[] = date('H:i', $t);
    }
    return $slots;
}

function day_short_from_date(string $date): string
{
    $map = ['Sun' => 'Sun', 'Mon' => 'Mon', 'Tue' => 'Tue', 'Wed' => 'Wed', 'Thu' => 'Thu', 'Fri' => 'Fri', 'Sat' => 'Sat'];
    $d = date('D', strtotime($date));
    return $map[$d] ?? $d;
}

function password_is_strong(string $p): bool
{
    if (strlen($p) < 8) {
        return false;
    }
    if (!preg_match('/[a-z]/', $p)) {
        return false;
    }
    if (!preg_match('/[A-Z]/', $p)) {
        return false;
    }
    if (!preg_match('/[0-9]/', $p)) {
        return false;
    }
    return true;
}

function badge_class_for_status(string $status): string
{
    if ($status === 'pending') {
        return 'warning';
    }
    if ($status === 'confirmed') {
        return 'info';
    }
    if ($status === 'completed') {
        return 'success';
    }
    if ($status === 'cancelled') {
        return 'danger';
    }
    return 'secondary';
}
