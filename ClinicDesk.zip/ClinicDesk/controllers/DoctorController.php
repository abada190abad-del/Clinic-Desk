<?php

require_once __DIR__ . '/../models/DoctorModel.php';
require_once __DIR__ . '/../models/SpecializationModel.php';

class DoctorController
{
    private DoctorModel $doctors;
    private SpecializationModel $specs;

    public function __construct()
    {
        $this->doctors = new DoctorModel();
        $this->specs = new SpecializationModel();
    }

    public function handle(string $action): void
    {
        if ($action === 'list' || $action === '' || $action === 'index') {
            Auth::requireRole('admin');
            $this->doctorList();
            return;
        }

        if ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            Auth::requireRole('admin', 'doctor');
            $this->doctorEditGet();
            return;
        }

        if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            Auth::requireRole('admin', 'doctor');
            $this->doctorUpdate();
            return;
        }

        flash('warning', 'Unknown doctor action.');
        redirect('index.php?page=dashboard');
    }

    private function doctorList(): void
    {
        $pageTitle = 'Doctors';
        $page = max(1, (int) ($_GET['p'] ?? 1));
        $total = $this->doctors->countAll();
        $paginator = new Paginator($total, ITEMS_PER_PAGE, $page);
        $rows = $this->doctors->getAllPaginated($page);
        $query = 'page=doctors&action=list';
        require __DIR__ . '/../views/doctors/list.php';
    }

    private function doctorEditGet(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $d = $this->doctors->findById($id);
        if ($d === null) {
            flash('danger', 'Doctor not found.');
            redirect('index.php?page=doctors&action=list');
        }

        if (Auth::role() === 'doctor') {
            $mine = $this->doctors->findByUserId(Auth::id());
            if ($mine === null || (int) $mine['id'] !== $id) {
                redirect('index.php?page=errors&action=forbidden');
            }
        }

        $pageTitle = 'Edit doctor';
        $specs = $this->specs->getAll();
        require __DIR__ . '/../views/doctors/edit.php';
    }

    private function doctorUpdate(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=doctors&action=list');
        }

        $id = (int) ($_POST['id'] ?? 0);
        $d = $this->doctors->findById($id);
        if ($d === null) {
            flash('danger', 'Doctor not found.');
            redirect('index.php?page=doctors&action=list');
        }

        if (Auth::role() === 'doctor') {
            $mine = $this->doctors->findByUserId(Auth::id());
            if ($mine === null || (int) $mine['id'] !== $id) {
                redirect('index.php?page=errors&action=forbidden');
            }
        }

        $specId = (int) ($_POST['specialization_id'] ?? 0);
        $fee = (float) ($_POST['consultation_fee'] ?? 0);
        $bio = sanitize((string) ($_POST['bio'] ?? ''));
        $days = $_POST['available_days'] ?? [];
        if (!is_array($days)) {
            $days = [];
        }
        $daysStr = implode(',', $days);
        if ($daysStr === '') {
            $daysStr = 'Sun,Mon,Tue,Wed,Thu';
        }

        if (Auth::role() === 'admin' && $specId <= 0) {
            flash('danger', 'Pick a specialization.');
            redirect('index.php?page=doctors&action=edit&id=' . $id);
        }

        if (Auth::role() === 'doctor') {
            $specId = (int) $d['specialization_id'];
        }

        $photoPath = $d['photo'];
        if (!empty($_FILES['doctor_photo']['name']) && (int) $_FILES['doctor_photo']['error'] === UPLOAD_ERR_OK) {
            $ph = $this->handleDoctorPhotoUpload($_FILES['doctor_photo']);
            if ($ph === null) {
                flash('danger', 'Doctor photo must be JPEG/PNG under 1 MB.');
                redirect('index.php?page=doctors&action=edit&id=' . $id);
            }
            $photoPath = $ph;
        }

        $this->doctors->update($id, [
            'specialization_id' => $specId,
            'bio' => $bio !== '' ? $bio : null,
            'consultation_fee' => $fee,
            'available_days' => $daysStr,
            'photo' => $photoPath,
        ]);

        flash('success', 'Doctor record saved.');
        if (Auth::role() === 'admin') {
            redirect('index.php?page=doctors&action=list');
        }
        redirect('index.php?page=profile');
    }

    private function handleDoctorPhotoUpload(array $file): ?string
    {
        if ($file['size'] > MAX_DOCTOR_PHOTO_BYTES) {
            return null;
        }
        $tmp = $file['tmp_name'];
        $info = @getimagesize($tmp);
        if ($info === false) {
            return null;
        }
        $mime = $info['mime'] ?? '';
        if ($mime !== 'image/jpeg' && $mime !== 'image/png') {
            return null;
        }
        $ext = $mime === 'image/png' ? 'png' : 'jpg';
        $name = 'doctor_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $destDir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'doctor_photos';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        $dest = $destDir . DIRECTORY_SEPARATOR . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            return null;
        }
        return 'public/uploads/doctor_photos/' . $name;
    }
}
