<?php

require_once __DIR__ . '/../models/UserModel.php';

class AuthController
{
    private UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function handle(string $action): void
    {
        if ($action === 'login') {
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->loginGet();
            } else {
                $this->loginPost();
            }
            return;
        }

        if ($action === 'logout') {
            Auth::requireRole('admin', 'doctor', 'patient');
            $this->logoutPost();
            return;
        }

        if ($action === 'change_password') {
            Auth::requireRole('admin', 'doctor', 'patient');
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->changePasswordGet();
            } else {
                $this->changePasswordPost();
            }
            return;
        }

        flash('warning', 'Unknown action.');
        redirect('index.php?page=auth&action=login');
    }

    private function loginGet(): void
    {
        if (Auth::check()) {
            redirect('index.php?page=dashboard');
        }
        require __DIR__ . '/../views/auth/login.php';
    }

    private function loginPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token. Try again.');
            redirect('index.php?page=auth&action=login');
        }

        $email = sanitize((string) ($_POST['email'] ?? ''));
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);

        try {
            $user = $this->users->findByEmail($email);
        } catch (Throwable $e) {
            flash('danger', 'Cannot connect to the database. Start MySQL in XAMPP and import sql/clinicdesk_db.sql (see README).');
            redirect('index.php?page=auth&action=login');
        }

        if ($user === null) {
            flash('danger', 'Invalid credentials.');
            redirect('index.php?page=auth&action=login');
        }

        if ((int) $user['is_active'] !== 1) {
            flash('danger', 'Account suspended. Contact admin.');
            redirect('index.php?page=auth&action=login');
        }

        $pass = (string) ($_POST['password'] ?? '');
        if (!password_verify($pass, $user['password'])) {
            flash('danger', 'Invalid credentials.');
            redirect('index.php?page=auth&action=login');
        }

        Auth::login($user);
        redirect('index.php?page=dashboard');
    }

    private function logoutPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=dashboard');
        }
        Auth::logout();
    }

    private function changePasswordGet(): void
    {
        $pageTitle = 'Change password';
        require __DIR__ . '/../views/auth/change_password.php';
    }

    private function changePasswordPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=auth&action=change_password');
        }

        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        $u = $this->users->findById(Auth::id());
        if ($u === null) {
            flash('danger', 'User not found.');
            redirect('index.php?page=auth&action=login');
        }

        if (!password_verify($current, $u['password'])) {
            flash('danger', 'Current password is wrong.');
            redirect('index.php?page=auth&action=change_password');
        }

        if ($new !== $confirm) {
            flash('danger', 'New passwords do not match.');
            redirect('index.php?page=auth&action=change_password');
        }

        if (!password_is_strong($new)) {
            flash('danger', 'New password must be at least 8 characters and include upper, lower, and a number.');
            redirect('index.php?page=auth&action=change_password');
        }

        $hash = password_hash($new, PASSWORD_BCRYPT);
        $this->users->updatePassword((int) $u['id'], $hash);
        $this->users->setFirstLogin((int) $u['id'], 0);

        $_SESSION['user']['first_login'] = 0;

        flash('success', 'Password updated.');
        redirect('index.php?page=dashboard');
    }
}
