<?php

require_once __DIR__ . '/../models/AppointmentModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';
require_once __DIR__ . '/../models/UserModel.php';

class ChatbotController
{
    private AppointmentModel $appointments;
    private DoctorModel $doctors;
    private UserModel $users;

    public function __construct()
    {
        $this->appointments = new AppointmentModel();
        $this->doctors = new DoctorModel();
        $this->users = new UserModel();
    }

    public function handle(string $action): void
    {
        if ($action === 'message' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->message();
            return;
        }

        $this->jsonReply('الطلب غير معروف.', 404);
    }

    private function message(): void
    {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!CSRF::validateToken($token)) {
            $this->jsonReply('انتهت صلاحية الجلسة، حدّث الصفحة وحاول مجدداً.', 403);
            return;
        }

        $input = json_decode((string) file_get_contents('php://input'), true) ?? [];
        $text = trim((string) ($input['message'] ?? ''));
        if ($text === '') {
            $this->jsonReply('الرجاء كتابة رسالة.');
            return;
        }

        if ($this->isCancelIntent($text)) {
            $this->resetBooking();
            $this->jsonReply('تم إلغاء عملية الحجز. كيف يمكنني مساعدتك؟');
            return;
        }

        if (!isset($_SESSION['chatbot_booking']) || !is_array($_SESSION['chatbot_booking'])) {
            $_SESSION['chatbot_booking'] = ['step' => null];
        }
        $booking = &$_SESSION['chatbot_booking'];

        if (!empty($booking['step'])) {
            $this->jsonReply($this->handleBookingStep($text, $booking));
            return;
        }

        if ($this->isBookingIntent($text)) {
            $booking['step'] = 'doctor';
            $this->jsonReply($this->doctorListMessage());
            return;
        }

        $history = is_array($input['history'] ?? null) ? $input['history'] : [];
        $this->jsonReply($this->generalReply($text, $history));
    }

    private function handleBookingStep(string $text, array &$booking): string
    {
        $step = $booking['step'] ?? '';

        if ($step === 'doctor') {
            return $this->stepDoctor($text, $booking);
        }
        if ($step === 'date') {
            return $this->stepDate($text, $booking);
        }
        if ($step === 'time') {
            return $this->stepTime($text, $booking);
        }
        if ($step === 'patient') {
            return $this->stepPatient($text, $booking);
        }
        if ($step === 'reason') {
            return $this->stepReason($text, $booking);
        }
        if ($step === 'confirm') {
            return $this->stepConfirm($text, $booking);
        }

        $this->resetBooking();
        return 'حدث خطأ في الحجز. اكتب «حجز موعد» للبدء من جديد.';
    }

    private function stepDoctor(string $text, array &$booking): string
    {
        $doctors = $this->doctors->getAll();
        if (count($doctors) === 0) {
            $this->resetBooking();
            return 'لا يوجد أطباء متاحون حالياً. تواصل مع الإدارة.';
        }

        $pick = (int) preg_replace('/\D/', '', $text);
        if ($pick < 1 || $pick > count($doctors)) {
            return "رقم غير صحيح.\n\n" . $this->formatDoctorList($doctors);
        }

        $doc = $doctors[$pick - 1];
        $booking['doctor_id'] = (int) $doc['id'];
        $booking['doctor_name'] = (string) $doc['doctor_name'];
        $booking['step'] = 'date';

        $days = $this->doctors->getAvailableDays((int) $doc['id']);
        $daysAr = array_map(fn ($d) => $this->dayAr($d), $days);

        return "اخترت د. {$doc['doctor_name']} — {$doc['specialization_name']}.\n"
            . 'أيام العمل: ' . implode('، ', $daysAr) . ".\n\n"
            . "أدخل تاريخ الموعد بصيغة YYYY-MM-DD\n(مثال: " . date('Y-m-d', strtotime('+1 day')) . ')';
    }

    private function stepDate(string $text, array &$booking): string
    {
        $date = $this->parseDate($text);
        if ($date === null) {
            return 'تاريخ غير صالح. استخدم الصيغة YYYY-MM-DD ولا تختر تاريخاً في الماضي.';
        }

        $doctorId = (int) ($booking['doctor_id'] ?? 0);
        $day = day_short_from_date($date);
        $allowed = $this->doctors->getAvailableDays($doctorId);
        if (!in_array($day, $allowed, true)) {
            $daysAr = array_map(fn ($d) => $this->dayAr($d), $allowed);
            return 'الطبيب غير متاح في هذا اليوم. أيام العمل: ' . implode('، ', $daysAr) . '.';
        }

        $slots = $this->getAvailableSlots($doctorId, $date);
        if (count($slots) === 0) {
            return 'لا توجد أوقات متاحة في هذا التاريخ. اختر تاريخاً آخر.';
        }

        $booking['appt_date'] = $date;
        $booking['slot_options'] = $slots;
        $booking['step'] = 'time';

        return $this->formatSlotList($slots, $date);
    }

    private function stepTime(string $text, array &$booking): string
    {
        $slots = $booking['slot_options'] ?? [];
        if (!is_array($slots) || count($slots) === 0) {
            $booking['step'] = 'date';
            return 'انتهت قائمة الأوقات. أدخل التاريخ مجدداً.';
        }

        $pick = (int) preg_replace('/\D/', '', $text);
        if ($pick < 1 || $pick > count($slots)) {
            return "رقم غير صحيح.\n\n" . $this->formatSlotList($slots, (string) $booking['appt_date']);
        }

        $booking['appt_time'] = $slots[$pick - 1];

        if ($this->isLoggedInPatient()) {
            $booking['step'] = 'reason';
            return "الوقت: {$booking['appt_time']}.\nاكتب سبب الزيارة (أو اكتب «تخطي»).";
        }

        $booking['step'] = 'patient';
        return "الوقت: {$booking['appt_time']}.\n\n"
            . "أدخل بياناتك بهذا الشكل:\nالاسم | الهاتف | البريد الإلكتروني\n"
            . 'مثال: أحمد علي | 0501234567 | ahmed@example.com';
    }

    private function stepPatient(string $text, array &$booking): string
    {
        $parts = array_map('trim', explode('|', $text));
        if (count($parts) < 3) {
            return "الصيغة غير صحيحة. استخدم:\nالاسم | الهاتف | البريد الإلكتروني";
        }

        [$name, $phone, $email] = $parts;
        if ($name === '' || $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return 'تأكد من إدخال الاسم وبريد إلكتروني صحيح.';
        }

        $booking['patient_name'] = $name;
        $booking['patient_phone'] = $phone;
        $booking['patient_email'] = $email;
        $booking['step'] = 'reason';

        return "شكراً {$name}.\nاكتب سبب الزيارة (أو اكتب «تخطي»).";
    }

    private function stepReason(string $text, array &$booking): string
    {
        $reason = mb_strtolower(trim($text));
        if (!in_array($reason, ['تخطي', 'skip', '-'], true)) {
            $booking['reason'] = $text;
        } else {
            $booking['reason'] = '';
        }

        $booking['step'] = 'confirm';
        return $this->confirmationMessage($booking);
    }

    private function stepConfirm(string $text, array &$booking): string
    {
        if (!$this->isYes($text)) {
            if ($this->isNo($text)) {
                $this->resetBooking();
                return 'تم إلغاء الحجز. اكتب «حجز موعد» إذا أردت البدء مجدداً.';
            }
            return $this->confirmationMessage($booking) . "\n\nاكتب «نعم» للتأكيد أو «لا» للإلغاء.";
        }

        $patientResult = $this->resolvePatientId($booking);
        if ($patientResult === null) {
            $this->resetBooking();
            return 'تعذّر إنشاء الحساب. البريد مستخدم لحساب غير مريض. جرّب بريداً آخر أو سجّل الدخول.';
        }

        $patientId = $patientResult['id'];
        $tempPassword = $patientResult['temp_password'] ?? null;
        $isExistingPatient = $patientResult['existing'] ?? false;

        $doctorId = (int) ($booking['doctor_id'] ?? 0);
        $date = (string) ($booking['appt_date'] ?? '');
        $time = (string) ($booking['appt_time'] ?? '');

        if ($this->appointments->hasConflict($doctorId, $date, $time)) {
            $booking['step'] = 'time';
            $slots = $this->getAvailableSlots($doctorId, $date);
            $booking['slot_options'] = $slots;
            if (count($slots) === 0) {
                $booking['step'] = 'date';
                return 'عذراً، هذا الوقت أصبح محجوزاً ولا توجد أوقات أخرى في نفس اليوم. اختر تاريخاً جديداً.';
            }
            return "عذراً، هذا الوقت أصبح محجوزاً. اختر وقتاً آخر:\n\n" . $this->formatSlotList($slots, $date);
        }

        $reason = trim((string) ($booking['reason'] ?? ''));
        $ok = $this->appointments->book([
            'patient_id' => $patientId,
            'doctor_id' => $doctorId,
            'appt_date' => $date,
            'appt_time' => $time,
            'status' => 'pending',
            'reason' => $reason !== '' ? $reason : null,
        ]);

        $doctorName = (string) ($booking['doctor_name'] ?? '');
        $patientEmail = (string) ($booking['patient_email'] ?? '');
        $this->resetBooking();

        if (!$ok) {
            return 'تعذّر إتمام الحجز. حاول مرة أخرى أو تواصل مع العيادة.';
        }

        $msg = "تم إرسال طلب الحجز بنجاح ✅\n"
            . "الطبيب: د. {$doctorName}\n"
            . "التاريخ: {$date}\n"
            . "الوقت: {$time}\n"
            . 'الحالة: قيد الانتظار حتى تأكيد الطبيب.';

        if (!$this->isLoggedInPatient()) {
            if ($tempPassword !== null) {
                $msg .= "\n\nتم إنشاء حسابك تلقائياً:"
                    . "\nالبريد: {$patientEmail}"
                    . "\nكلمة المرور المؤقتة: {$tempPassword}"
                    . "\n\nسجّل الدخول وستُطلب منك تغيير كلمة المرور فوراً.";
            } elseif ($isExistingPatient) {
                $msg .= "\n\nيمكنك تسجيل الدخول بحسابك الحالي لمتابعة الموعد.";
            }
        }

        return $msg;
    }

    private function resolvePatientId(array &$booking): ?array
    {
        if ($this->isLoggedInPatient()) {
            return ['id' => Auth::id(), 'temp_password' => null, 'existing' => true];
        }

        $email = strtolower(trim((string) ($booking['patient_email'] ?? '')));
        $name = trim((string) ($booking['patient_name'] ?? ''));
        $phone = trim((string) ($booking['patient_phone'] ?? ''));

        $existing = $this->users->findByEmail($email);
        if ($existing !== null) {
            if (($existing['role'] ?? '') !== 'patient') {
                return null;
            }
            if ((int) ($existing['is_active'] ?? 0) !== 1) {
                return null;
            }
            return ['id' => (int) $existing['id'], 'temp_password' => null, 'existing' => true];
        }

        $plainPassword = $this->generateTempPassword();
        $id = $this->users->create([
            'name' => $name,
            'email' => $email,
            'password' => password_hash($plainPassword, PASSWORD_BCRYPT),
            'role' => 'patient',
            'phone' => $phone !== '' ? $phone : null,
            'first_login' => 1,
        ]);

        if ($id <= 0) {
            return null;
        }

        return ['id' => $id, 'temp_password' => $plainPassword, 'existing' => false];
    }

    private function generateTempPassword(): string
    {
        return 'Clinic@' . random_int(10000, 99999);
    }

    private function confirmationMessage(array $booking): string
    {
        $lines = [
            'ملخص الحجز:',
            'الطبيب: د. ' . ($booking['doctor_name'] ?? ''),
            'التاريخ: ' . ($booking['appt_date'] ?? ''),
            'الوقت: ' . ($booking['appt_time'] ?? ''),
        ];

        if (!$this->isLoggedInPatient()) {
            $lines[] = 'الاسم: ' . ($booking['patient_name'] ?? '');
            $lines[] = 'البريد: ' . ($booking['patient_email'] ?? '');
        }

        $reason = trim((string) ($booking['reason'] ?? ''));
        if ($reason !== '') {
            $lines[] = 'السبب: ' . $reason;
        }

        $lines[] = '';
        $lines[] = 'هل تؤكد الحجز؟ (نعم / لا)';

        return implode("\n", $lines);
    }

    private function doctorListMessage(): string
    {
        $doctors = $this->doctors->getAll();
        if (count($doctors) === 0) {
            $this->resetBooking();
            return 'لا يوجد أطباء متاحون حالياً.';
        }

        return "لنبدأ الحجز 🗓️\n\n" . $this->formatDoctorList($doctors);
    }

    private function formatDoctorList(array $doctors): string
    {
        $lines = ['اختر الطبيب بكتابة رقمه:'];
        foreach ($doctors as $i => $doc) {
            $fee = number_format((float) $doc['consultation_fee'], 2);
            $lines[] = ($i + 1) . '. د. ' . $doc['doctor_name']
                . ' — ' . $doc['specialization_name']
                . " ({$fee})";
        }
        $lines[] = '';
        $lines[] = 'اكتب «إلغاء» في أي وقت لإيقاف الحجز.';

        return implode("\n", $lines);
    }

    private function formatSlotList(array $slots, string $date): string
    {
        $lines = ["الأوقات المتاحة يوم {$date}:"];
        foreach ($slots as $i => $slot) {
            $lines[] = ($i + 1) . '. ' . $slot;
        }
        $lines[] = '';
        $lines[] = 'اكتب رقم الوقت المناسب.';

        return implode("\n", $lines);
    }

    private function getAvailableSlots(int $doctorId, string $date): array
    {
        $available = [];
        foreach (appt_time_slots() as $slot) {
            if (!$this->appointments->hasConflict($doctorId, $date, $slot)) {
                $available[] = $slot;
            }
        }
        return $available;
    }

    private function generalReply(string $text, array $history): string
    {
        $apiKey = defined('OPENAI_API_KEY') ? (string) OPENAI_API_KEY : '';
        if ($apiKey === '') {
            return $this->fallbackReply();
        }

        $messages = [['role' => 'system', 'content' => $this->buildSystemPrompt()]];
        foreach ($history as $turn) {
            if (!is_array($turn)) {
                continue;
            }
            $role = $turn['role'] ?? '';
            $content = trim((string) ($turn['content'] ?? ''));
            if ($content === '' || !in_array($role, ['user', 'assistant'], true)) {
                continue;
            }
            $messages[] = ['role' => $role, 'content' => $content];
        }
        $messages[] = ['role' => 'user', 'content' => $text];

        $payload = json_encode([
            'model' => defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini',
            'messages' => $messages,
            'temperature' => 0.3,
            'max_tokens' => 400,
        ]);

        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
        ]);

        $body = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($body === false || $err !== '') {
            return $this->fallbackReply();
        }

        $data = json_decode($body, true);
        $reply = trim((string) ($data['choices'][0]['message']['content'] ?? ''));
        if ($reply === '') {
            return $this->fallbackReply();
        }

        return $reply;
    }

    private function buildSystemPrompt(): string
    {
        $info = "أنت مساعد عيادة " . APP_NAME . "، ترد بالعربية بإيجاز ووضوح.\n";
        $info .= "أوقات الحجز: من 09:00 إلى 16:00 كل 30 دقيقة.\n";
        $info .= "لحجز موعد فعلي اطلب من المستخدم كتابة «حجز موعد».\n";
        $info .= "لا تقدّم تشخيصاً طبياً.\n\nالأطباء المتاحون:\n";

        foreach ($this->doctors->getAll() as $doc) {
            $days = $this->doctors->getAvailableDays((int) $doc['id']);
            $daysAr = array_map(fn ($d) => $this->dayAr($d), $days);
            $info .= '- د. ' . $doc['doctor_name'] . ' (' . $doc['specialization_name'] . ') — '
                . implode('، ', $daysAr) . "\n";
        }

        if (Auth::check()) {
            $user = Auth::currentUser();
            $info .= "\nالمستخدم الحالي: " . ($user['name'] ?? '') . ' (' . Auth::role() . ").\n";
            if (Auth::role() === 'patient') {
                $rows = $this->appointments->getByPatient(Auth::id(), 1, []);
                if (count($rows) > 0) {
                    $info .= "آخر مواعيده:\n";
                    foreach (array_slice($rows, 0, 5) as $a) {
                        $info .= '- ' . $a['appt_date'] . ' ' . $a['appt_time']
                            . ' — ' . ($a['status'] ?? '') . "\n";
                    }
                }
            }
        } else {
            $info .= "\nالمستخدم غير مسجّل الدخول — يمكنه الحجز عبر كتابة «حجز موعد».\n";
        }

        return $info;
    }

    private function fallbackReply(): string
    {
        return "يمكنني مساعدتك في حجز موعد مع أحد أطبائنا.\n"
            . "اكتب «حجز موعد» للبدء، أو اسأل عن أوقات الدوام والتخصصات.\n"
            . "للاستفسارات العامة يمكنك أيضاً تسجيل الدخول لمتابعة مواعيدك.";
    }

    private function isBookingIntent(string $text): bool
    {
        $t = mb_strtolower($text);
        $keywords = ['حجز', 'موعد', 'appointment', 'book', 'احجز', 'حجز موعد', 'ابي موعد', 'أبي موعد', 'بدي موعد'];
        foreach ($keywords as $kw) {
            if (mb_strpos($t, $kw) !== false) {
                return true;
            }
        }
        return false;
    }

    private function isCancelIntent(string $text): bool
    {
        $t = mb_strtolower(trim($text));
        return in_array($t, ['إلغاء', 'الغاء', 'cancel', 'stop', 'وقف'], true);
    }

    private function isYes(string $text): bool
    {
        $t = mb_strtolower(trim($text));
        return in_array($t, ['نعم', 'اي', 'أي', 'ايوه', 'أيوه', 'yes', 'y', 'ok', 'تم', 'موافق'], true);
    }

    private function isNo(string $text): bool
    {
        $t = mb_strtolower(trim($text));
        return in_array($t, ['لا', 'no', 'n'], true);
    }

    private function isLoggedInPatient(): bool
    {
        return Auth::check() && Auth::role() === 'patient';
    }

    private function parseDate(string $text): ?string
    {
        $text = trim($text);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $text)) {
            return null;
        }
        $ts = strtotime($text);
        if ($ts === false || $ts < strtotime(date('Y-m-d'))) {
            return null;
        }
        return date('Y-m-d', $ts);
    }

    private function dayAr(string $en): string
    {
        $map = [
            'Sun' => 'الأحد',
            'Mon' => 'الإثنين',
            'Tue' => 'الثلاثاء',
            'Wed' => 'الأربعاء',
            'Thu' => 'الخميس',
            'Fri' => 'الجمعة',
            'Sat' => 'السبت',
        ];
        return $map[$en] ?? $en;
    }

    private function resetBooking(): void
    {
        unset($_SESSION['chatbot_booking']);
    }

    private function jsonReply(string $reply, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['reply' => $reply], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
