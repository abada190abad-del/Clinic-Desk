<?php

require_once __DIR__ . '/../models/AppointmentModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';
require_once __DIR__ . '/../models/PrescriptionModel.php';

class AppointmentController
{
    private AppointmentModel $appointments;
    private DoctorModel $doctors;
    private PrescriptionModel $prescriptions;

    public function __construct()
    {
        $this->appointments = new AppointmentModel();
        $this->doctors = new DoctorModel();
        $this->prescriptions = new PrescriptionModel();
    }

    public function handle(string $action): void
    {
        if ($action === 'index' || $action === '') {
            $action = 'list';
        }

        if ($action === 'book') {
            Auth::requireRole('patient');
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->bookGet();
            } else {
                $this->bookPost();
            }
            return;
        }

        if ($action === 'list') {
            Auth::requireRole('admin', 'doctor', 'patient');
            $this->listGet();
            return;
        }

        if ($action === 'detail') {
            Auth::requireRole('admin', 'doctor', 'patient');
            $this->detailGet();
            return;
        }

        if ($action === 'cancel' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            Auth::requireRole('patient');
            $this->cancelPost();
            return;
        }

        if ($action === 'set_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            Auth::requireRole('admin', 'doctor');
            $this->setStatusPost();
            return;
        }

        if ($action === 'save_notes' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            Auth::requireRole('doctor');
            $this->saveNotesPost();
            return;
        }

        flash('warning', 'Unknown appointment action.');
        redirect('index.php?page=dashboard');
    }

    private function bookGet(): void
    {
        $pageTitle = 'Book appointment';
        $doctorList = $this->doctors->getAll();
        $slots = appt_time_slots();
        require __DIR__ . '/../views/appointments/book.php';
    }

    private function bookPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=appointments&action=book');
        }

        $doctorId = (int) ($_POST['doctor_id'] ?? 0);
        $date = sanitize((string) ($_POST['appt_date'] ?? ''));
        $time = sanitize((string) ($_POST['appt_time'] ?? ''));
        $reason = sanitize((string) ($_POST['reason'] ?? ''));

        if ($doctorId <= 0 || $date === '' || $time === '') {
            flash('danger', 'Please fill doctor, date, and time.');
            redirect('index.php?page=appointments&action=book');
        }

        if (strtotime($date) < strtotime(date('Y-m-d'))) {
            flash('danger', 'Date cannot be in the past.');
            redirect('index.php?page=appointments&action=book');
        }

        $doc = $this->doctors->findById($doctorId);
        if ($doc === null) {
            flash('danger', 'Doctor not found.');
            redirect('index.php?page=appointments&action=book');
        }

        $day = day_short_from_date($date);
        $allowed = $this->doctors->getAvailableDays($doctorId);
        if (!in_array($day, $allowed, true)) {
            flash('danger', 'Doctor is not available on that weekday.');
            redirect('index.php?page=appointments&action=book');
        }

        if ($this->appointments->hasConflict($doctorId, $date, $time)) {
            flash('danger', 'This slot is already booked, please choose another time.');
            redirect('index.php?page=appointments&action=book');
        }

        $ok = $this->appointments->book([
            'patient_id' => Auth::id(),
            'doctor_id' => $doctorId,
            'appt_date' => $date,
            'appt_time' => $time,
            'status' => 'pending',
            'reason' => $reason !== '' ? $reason : null,
        ]);

        if (!$ok) {
            flash('danger', 'Could not book (maybe the slot was taken).');
            redirect('index.php?page=appointments&action=book');
        }

        flash('success', 'Appointment requested.');
        redirect('index.php?page=appointments&action=list');
    }

    private function listGet(): void
    {
        $pageTitle = 'Appointments';
        $page = max(1, (int) ($_GET['p'] ?? 1));

        $filters = [
            'status' => sanitize((string) ($_GET['status'] ?? '')),
            'date_from' => sanitize((string) ($_GET['date_from'] ?? '')),
            'date_to' => sanitize((string) ($_GET['date_to'] ?? '')),
            'doctor_id' => (int) ($_GET['doctor_id'] ?? 0),
            'patient_search' => sanitize((string) ($_GET['patient_search'] ?? '')),
        ];

        $role = Auth::role();
        if ($role === 'patient') {
            $scope = 'patient';
            $scopeId = Auth::id();
            $total = $this->appointments->countFiltered($scope, $scopeId, $filters);
            $paginator = new Paginator($total, ITEMS_PER_PAGE, $page);
            $rows = $this->appointments->getByPatient($scopeId, $page, $filters);
            $todayRows = [];
            require __DIR__ . '/../views/appointments/list_patient.php';
            return;
        }

        if ($role === 'doctor') {
            $doc = $this->doctors->findByUserId(Auth::id());
            if ($doc === null) {
                flash('danger', 'Doctor profile missing.');
                redirect('index.php?page=dashboard');
            }
            $doctorId = (int) $doc['id'];
            $scope = 'doctor';
            $total = $this->appointments->countFiltered($scope, $doctorId, $filters);
            $paginator = new Paginator($total, ITEMS_PER_PAGE, $page);
            $rows = $this->appointments->getByDoctor($doctorId, $page, $filters);
            $todayRows = $this->appointments->getTodayForDoctor($doctorId);
            require __DIR__ . '/../views/appointments/list_doctor.php';
            return;
        }

        $scope = 'admin';
        $total = $this->appointments->countFiltered($scope, 0, $filters);
        $paginator = new Paginator($total, ITEMS_PER_PAGE, $page);
        $rows = $this->appointments->getAll($page, $filters);
        $doctorDropdown = $this->doctors->getAll();
        require __DIR__ . '/../views/appointments/list_admin.php';
    }

    private function detailGet(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $a = $this->appointments->findById($id);
        if ($a === null) {
            flash('danger', 'Appointment not found.');
            redirect('index.php?page=appointments&action=list');
        }

        if (! $this->canViewAppointment($a)) {
            redirect('index.php?page=errors&action=forbidden');
        }

        $pageTitle = 'Appointment #' . $id;
        $rx = $this->prescriptions->findByAppointmentId($id);
        $docMine = null;
        if (Auth::role() === 'doctor') {
            $docMine = $this->doctors->findByUserId(Auth::id());
        }
        require __DIR__ . '/../views/appointments/detail.php';
    }

    private function canViewAppointment(array $a): bool
    {
        $role = Auth::role();
        if ($role === 'admin') {
            return true;
        }
        if ($role === 'patient') {
            return (int) $a['patient_id'] === Auth::id();
        }
        if ($role === 'doctor') {
            $doc = $this->doctors->findByUserId(Auth::id());
            if ($doc === null) {
                return false;
            }
            return (int) $a['doctor_id'] === (int) $doc['id'];
        }
        return false;
    }

    private function cancelPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=appointments&action=list');
        }
        $id = (int) ($_POST['id'] ?? 0);
        $a = $this->appointments->findById($id);
        if ($a === null || (int) $a['patient_id'] !== Auth::id()) {
            flash('danger', 'Not allowed.');
            redirect('index.php?page=appointments&action=list');
        }
        if ($a['status'] !== 'pending') {
            flash('danger', 'Only pending appointments can be cancelled.');
            redirect('index.php?page=appointments&action=list');
        }
        $this->appointments->updateStatus($id, 'cancelled');
        flash('success', 'Appointment cancelled.');
        redirect('index.php?page=appointments&action=list');
    }

    private function setStatusPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=appointments&action=list');
        }

        $id = (int) ($_POST['id'] ?? 0);
        $newStatus = sanitize((string) ($_POST['status'] ?? ''));
        $a = $this->appointments->findById($id);
        if ($a === null) {
            flash('danger', 'Appointment not found.');
            redirect('index.php?page=appointments&action=list');
        }

        if (Auth::role() === 'doctor') {
            $doc = $this->doctors->findByUserId(Auth::id());
            if ($doc === null || (int) $a['doctor_id'] !== (int) $doc['id']) {
                redirect('index.php?page=errors&action=forbidden');
            }
            if (! $this->doctorCanSetStatus($a['status'], $newStatus)) {
                flash('danger', 'That status change is not allowed.');
                redirect('index.php?page=appointments&action=detail&id=' . $id);
            }
        } else {
            if (!in_array($newStatus, ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
                flash('danger', 'Invalid status.');
                redirect('index.php?page=appointments&action=detail&id=' . $id);
            }
        }

        $notes = sanitize((string) ($_POST['doctor_notes'] ?? ''));
        if ($notes !== '') {
            $this->appointments->updateDoctorNotes($id, $notes);
        }

        $this->appointments->updateStatus($id, $newStatus);
        flash('success', 'Status updated.');
        redirect('index.php?page=appointments&action=detail&id=' . $id);
    }

    private function doctorCanSetStatus(string $current, string $new): bool
    {
        if ($new === 'confirmed' && $current === 'pending') {
            return true;
        }
        if ($new === 'completed' && $current === 'confirmed') {
            return true;
        }
        if ($new === 'cancelled' && ($current === 'pending' || $current === 'confirmed')) {
            return true;
        }
        return false;
    }

    private function saveNotesPost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=appointments&action=list');
        }
        $id = (int) ($_POST['id'] ?? 0);
        $notes = sanitize((string) ($_POST['doctor_notes'] ?? ''));
        $a = $this->appointments->findById($id);
        if ($a === null) {
            flash('danger', 'Appointment not found.');
            redirect('index.php?page=appointments&action=list');
        }
        $doc = $this->doctors->findByUserId(Auth::id());
        if ($doc === null || (int) $a['doctor_id'] !== (int) $doc['id']) {
            redirect('index.php?page=errors&action=forbidden');
        }
        $this->appointments->updateDoctorNotes($id, $notes);
        flash('success', 'Notes saved.');
        redirect('index.php?page=appointments&action=detail&id=' . $id);
    }
}
