<?php

require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../models/AppointmentModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';
class DashboardController
{
    private UserModel $users;
    private AppointmentModel $appointments;
    private DoctorModel $doctors;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->appointments = new AppointmentModel();
        $this->doctors = new DoctorModel();
    }

    public function index(): void
    {
        Auth::requireRole('admin', 'doctor', 'patient');
        $role = Auth::role();

        if ($role === 'admin') {
            $pageTitle = 'Admin dashboard';
            $statsRoles = $this->users->statsByRole();
            $apptToday = $this->appointments->countTodayAll();
            $weekByStatus = $this->appointments->countThisWeekByStatus();
            $recent = $this->appointments->getRecentForAdmin(5);
            require __DIR__ . '/../views/dashboard/admin.php';
            return;
        }

        if ($role === 'doctor') {
            $pageTitle = 'Doctor dashboard';
            $doc = $this->doctors->findByUserId(Auth::id());
            if ($doc === null) {
                $today = [];
                $totalMonth = 0;
                $pendingMonth = 0;
                $completedMonth = 0;
                $upcoming = [];
                flash('danger', 'Doctor profile is missing. Contact admin.');
                require __DIR__ . '/../views/dashboard/doctor.php';
                return;
            }
            $doctorId = (int) $doc['id'];
            $today = $this->appointments->getTodayForDoctor($doctorId);
            $totalMonth = $this->appointments->countThisMonthForDoctor($doctorId);
            $pendingMonth = $this->appointments->countByStatusForDoctorMonth($doctorId, 'pending');
            $completedMonth = $this->appointments->countByStatusForDoctorMonth($doctorId, 'completed');
            $upcoming = $this->appointments->getNextForDoctor($doctorId, 5);
            require __DIR__ . '/../views/dashboard/doctor.php';
            return;
        }

        $pageTitle = 'Patient dashboard';
        $pid = Auth::id();
        $activeCount = $this->appointments->countPatientActive($pid);
        $activeList = $this->appointments->getPatientActiveList($pid);
        $completedCount = $this->appointments->countPatientCompleted($pid);
        $rxCount = $this->appointments->countPrescriptionsForPatient($pid);
        $next = $this->appointments->getPatientNextUpcoming($pid);
        require __DIR__ . '/../views/dashboard/patient.php';
    }
}
