<?php

require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../models/SpecializationModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';

class UserController
{
    private UserModel $users;
    private SpecializationModel $specs;
    private DoctorModel $doctors;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->specs = new SpecializationModel();
        $this->doctors = new DoctorModel();
    }

    public function specializations(string $action): void
    {
        Auth::requireRole('admin');

        if ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->specDelete();
            return;
        }

        if ($action === 'store' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->specStore();
            return;
        }

        $pageTitle = 'Specializations';
        $list = $this->specs->getAll();
        require __DIR__ . '/../views/specializations/index.php';
    }

    private function specStore(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=specializations');
        }
        $name = sanitize((string) ($_POST['name'] ?? ''));
        if ($name === '') {
            flash('danger', 'Name is required.');
            redirect('index.php?page=specializations');
        }
        try {
            $this->specs->create($name);
            flash('success', 'Specialization added.');
        } catch (Throwable $e) {
            flash('danger', 'Could not add specialization (maybe duplicate name).');
        }
        redirect('index.php?page=specializations');
    }

    private function specDelete(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=specializations');
        }
        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0) {
            flash('danger', 'Invalid id.');
            redirect('index.php?page=specializations');
        }
        if (!$this->specs->isSafeToDelete($id)) {
            flash('danger', 'Cannot delete: doctors still use this specialization.');
            redirect('index.php?page=specializations');
        }
        $this->specs->delete($id);
        flash('success', 'Specialization deleted.');
        redirect('index.php?page=specializations');
    }

    public function handle(string $action): void
    {
        Auth::requireRole('admin');

        if ($action === 'list' || $action === '' || $action === 'index') {
            $this->userList();
            return;
        }
        if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->userCreateGet();
            return;
        }
        if ($action === 'store' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userStore();
            return;
        }
        if ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->userEditGet();
            return;
        }
        if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userUpdate();
            return;
        }
        if ($action === 'toggle' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userToggle();
            return;
        }
        if ($action === 'reset_password' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userResetPassword();
            return;
        }

        flash('warning', 'Unknown user action.');
        redirect('index.php?page=users&action=list');
    }

    private function userList(): void
    {
        $pageTitle = 'Users';
        $role = sanitize((string) ($_GET['role'] ?? ''));
        $search = sanitize((string) ($_GET['q'] ?? ''));
        $page = max(1, (int) ($_GET['p'] ?? 1));

        $total = $this->users->countAll($role, $search);
        $paginator = new Paginator($total, ITEMS_PER_PAGE, $page);
        $rows = $this->users->getAllPaginated($page, $role, $search);

        $query = http_build_query(['page' => 'users', 'action' => 'list', 'role' => $role, 'q' => $search]);

        require __DIR__ . '/../views/users/list.php';
    }

    private function userCreateGet(): void
    {
        $pageTitle = 'Create user';
        $specs = $this->specs->getAll();
        require __DIR__ . '/../views/users/create.php';
    }

    private function userStore(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=users&action=create');
        }

        $name = sanitize((string) ($_POST['name'] ?? ''));
        $email = sanitize((string) ($_POST['email'] ?? ''));
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $phone = sanitize((string) ($_POST['phone'] ?? ''));
        $role = sanitize((string) ($_POST['role'] ?? 'patient'));
        $tempPass = (string) ($_POST['temp_password'] ?? '');

        if (!in_array($role, ['admin', 'doctor', 'patient'], true)) {
            flash('danger', 'Invalid role.');
            redirect('index.php?page=users&action=create');
        }

        if ($name === '' || $email === '' || $tempPass === '') {
            flash('danger', 'Name, email, and temporary password are required.');
            redirect('index.php?page=users&action=create');
        }

        $hash = password_hash($tempPass, PASSWORD_BCRYPT);

        $uid = $this->users->create([
            'name' => $name,
            'email' => $email,
            'password' => $hash,
            'role' => $role,
            'phone' => $phone !== '' ? $phone : null,
            'first_login' => $role === 'admin' ? 0 : 1,
        ]);

        if ($role === 'doctor') {
            $specId = (int) ($_POST['specialization_id'] ?? 0);
            $fee = (float) ($_POST['consultation_fee'] ?? 0);
            $bio = sanitize((string) ($_POST['bio'] ?? ''));
            $days = $_POST['available_days'] ?? [];
            if (!is_array($days)) {
                $days = [];
            }
            $daysStr = implode(',', $days);
            if ($specId <= 0) {
                flash('danger', 'Doctor needs a specialization.');
                redirect('index.php?page=users&action=create');
            }
            $this->doctors->create([
                'user_id' => $uid,
                'specialization_id' => $specId,
                'bio' => $bio !== '' ? $bio : null,
                'consultation_fee' => $fee,
                'available_days' => $daysStr !== '' ? $daysStr : 'Sun,Mon,Tue,Wed,Thu',
                'photo' => null,
            ]);
        }

        flash('success', 'User created.');
        redirect('index.php?page=users&action=list');
    }

    private function userEditGet(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $u = $this->users->findById($id);
        if ($u === null) {
            flash('danger', 'User not found.');
            redirect('index.php?page=users&action=list');
        }
        $pageTitle = 'Edit user';
        $specs = $this->specs->getAll();
        $doctor = null;
        if ($u['role'] === 'doctor') {
            $doctor = $this->doctors->findByUserId((int) $u['id']);
        }
        require __DIR__ . '/../views/users/edit.php';
    }

    private function userUpdate(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=users&action=list');
        }

        $id = (int) ($_POST['id'] ?? 0);
        $u = $this->users->findById($id);
        if ($u === null) {
            flash('danger', 'User not found.');
            redirect('index.php?page=users&action=list');
        }

        $name = sanitize((string) ($_POST['name'] ?? ''));
        $phone = sanitize((string) ($_POST['phone'] ?? ''));
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if ($name === '') {
            flash('danger', 'Name is required.');
            redirect('index.php?page=users&action=edit&id=' . $id);
        }

        $avatarPath = $u['avatar'];
        if (!empty($_FILES['avatar']['name']) && (int) $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $saved = $this->handleAvatarUpload($_FILES['avatar']);
            if ($saved === null) {
                flash('danger', 'Avatar must be a JPEG/PNG under 1 MB.');
                redirect('index.php?page=users&action=edit&id=' . $id);
            }
            $avatarPath = $saved;
        }

        $this->users->update($id, [
            'name' => $name,
            'phone' => $phone !== '' ? $phone : null,
            'avatar' => $avatarPath,
        ]);

        $oldActive = (int) $u['is_active'];
        if ($oldActive !== $isActive) {
            if (Auth::id() === $id && $isActive === 0) {
                flash('warning', 'You cannot deactivate your own account.');
            } else {
                $this->users->updateActive($id, $isActive);
            }
        }

        flash('success', 'User updated.');
        redirect('index.php?page=users&action=edit&id=' . $id);
    }

    private function userToggle(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=users&action=list');
        }
        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0) {
            flash('danger', 'Invalid user.');
            redirect('index.php?page=users&action=list');
        }
        if (Auth::id() === $id) {
            flash('danger', 'You cannot deactivate your own account.');
            redirect('index.php?page=users&action=list');
        }
        $this->users->toggleActive($id);
        flash('success', 'User status updated.');
        redirect('index.php?page=users&action=list');
    }

    private function userResetPassword(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=users&action=list');
        }
        $id = (int) ($_POST['id'] ?? 0);
        $new = (string) ($_POST['new_password'] ?? '');
        if ($id <= 0 || $new === '') {
            flash('danger', 'Invalid data.');
            redirect('index.php?page=users&action=list');
        }
        $hash = password_hash($new, PASSWORD_BCRYPT);
        $this->users->updatePassword($id, $hash);
        $this->users->setFirstLogin($id, 1);
        flash('success', 'Password reset. User must use the new password.');
        redirect('index.php?page=users&action=edit&id=' . $id);
    }

    private function handleAvatarUpload(array $file): ?string
    {
        if ($file['size'] > MAX_AVATAR_BYTES) {
            return null;
        }
        $tmp = $file['tmp_name'];
        $info = @getimagesize($tmp);
        if ($info === false) {
            return null;
        }
        $mime = $info['mime'] ?? '';
        if ($mime !== 'image/jpeg' && $mime !== 'image/png') {
            return null;
        }
        $ext = $mime === 'image/png' ? 'png' : 'jpg';
        $name = 'avatar_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $destDir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'avatars';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        $dest = $destDir . DIRECTORY_SEPARATOR . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            return null;
        }
        return 'public/uploads/avatars/' . $name;
    }

    public function me(string $action): void
    {
        Auth::requireRole('admin', 'doctor', 'patient');

        if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->meUpdate();
            return;
        }

        $pageTitle = 'My profile';
        $u = $this->users->findById(Auth::id());
        if ($u === null) {
            flash('danger', 'User missing.');
            redirect('index.php?page=dashboard');
        }
        $doctor = null;
        if ($u['role'] === 'doctor') {
            $doctor = $this->doctors->findByUserId((int) $u['id']);
        }
        require __DIR__ . '/../views/users/profile.php';
    }

    private function meUpdate(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=profile');
        }

        $id = Auth::id();
        $u = $this->users->findById($id);
        if ($u === null) {
            flash('danger', 'User missing.');
            redirect('index.php?page=dashboard');
        }

        $name = sanitize((string) ($_POST['name'] ?? ''));
        $phone = sanitize((string) ($_POST['phone'] ?? ''));
        if ($name === '') {
            flash('danger', 'Name is required.');
            redirect('index.php?page=profile');
        }

        $avatarPath = $u['avatar'];
        if (!empty($_FILES['avatar']['name']) && (int) $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $saved = $this->handleAvatarUpload($_FILES['avatar']);
            if ($saved === null) {
                flash('danger', 'Avatar must be JPEG/PNG under 1 MB.');
                redirect('index.php?page=profile');
            }
            $avatarPath = $saved;
        }

        $this->users->update($id, [
            'name' => $name,
            'phone' => $phone !== '' ? $phone : null,
            'avatar' => $avatarPath,
        ]);

        if ($u['role'] === 'doctor') {
            $doc = $this->doctors->findByUserId($id);
            if ($doc !== null) {
                $specId = (int) $doc['specialization_id'];
                $fee = (float) ($_POST['consultation_fee'] ?? $doc['consultation_fee']);
                $bio = sanitize((string) ($_POST['bio'] ?? ''));
                $days = $_POST['available_days'] ?? [];
                if (!is_array($days)) {
                    $days = [];
                }
                $daysStr = implode(',', $days);
                if ($daysStr === '') {
                    $daysStr = (string) $doc['available_days'];
                }

                $photoPath = $doc['photo'];
                if (!empty($_FILES['doctor_photo']['name']) && (int) $_FILES['doctor_photo']['error'] === UPLOAD_ERR_OK) {
                    $ph = $this->handleDoctorPhotoUpload($_FILES['doctor_photo']);
                    if ($ph === null) {
                        flash('danger', 'Doctor photo must be JPEG/PNG under 1 MB.');
                        redirect('index.php?page=profile');
                    }
                    $photoPath = $ph;
                }

                $this->doctors->update((int) $doc['id'], [
                    'specialization_id' => $specId,
                    'bio' => $bio !== '' ? $bio : null,
                    'consultation_fee' => $fee,
                    'available_days' => $daysStr,
                    'photo' => $photoPath,
                ]);
            }
        }

        flash('success', 'Profile saved.');
        redirect('index.php?page=profile');
    }

    private function handleDoctorPhotoUpload(array $file): ?string
    {
        if ($file['size'] > MAX_DOCTOR_PHOTO_BYTES) {
            return null;
        }
        $tmp = $file['tmp_name'];
        $info = @getimagesize($tmp);
        if ($info === false) {
            return null;
        }
        $mime = $info['mime'] ?? '';
        if ($mime !== 'image/jpeg' && $mime !== 'image/png') {
            return null;
        }
        $ext = $mime === 'image/png' ? 'png' : 'jpg';
        $name = 'doctor_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $destDir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'doctor_photos';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        $dest = $destDir . DIRECTORY_SEPARATOR . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            return null;
        }
        return 'public/uploads/doctor_photos/' . $name;
    }
}
