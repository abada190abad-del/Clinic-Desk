<?php

require_once __DIR__ . '/../models/AppointmentModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';

class ReportController
{
    private AppointmentModel $appointments;
    private DoctorModel $doctors;

    public function __construct()
    {
        $this->appointments = new AppointmentModel();
        $this->doctors = new DoctorModel();
    }

    public function handle(string $action): void
    {
        Auth::requireRole('admin');

        if ($action === '' || $action === 'index') {
            $this->indexGet();
            return;
        }

        flash('warning', 'Unknown report action.');
        redirect('index.php?page=reports');
    }

    private function indexGet(): void
    {
        $pageTitle = 'Reports';

        $start = sanitize((string) ($_GET['start_date'] ?? ''));
        $end = sanitize((string) ($_GET['end_date'] ?? ''));
        $doctorId = (int) ($_GET['doctor_id'] ?? 0);
        $status = sanitize((string) ($_GET['status'] ?? ''));
        $patientSearch = sanitize((string) ($_GET['patient_search'] ?? ''));

        $rows = [];
        $summary = ['total' => 0, 'by_status' => []];

        $export = ($_GET['export'] ?? '') === 'csv';

        if ($start !== '' && $end !== '') {
            if (strtotime($start) > strtotime($end)) {
                flash('danger', 'Start date must be before end date.');
                redirect('index.php?page=reports');
            }

            $docFilter = $doctorId > 0 ? $doctorId : null;
            $rows = $this->appointments->getForReport($start, $end, $docFilter, $status, $patientSearch);

            $summary['total'] = count($rows);
            foreach ($rows as $r) {
                $st = $r['status'];
                if (!isset($summary['by_status'][$st])) {
                    $summary['by_status'][$st] = 0;
                }
                $summary['by_status'][$st]++;
            }

            if ($export) {
                header('Content-Type: text/csv');
                header('Content-Disposition: attachment; filename="appointments_report.csv"');
                $out = fopen('php://output', 'w');
                fputcsv($out, ['Patient', 'Doctor', 'Specialization', 'Date', 'Time', 'Status', 'Reason']);
                foreach ($rows as $r) {
                    fputcsv($out, [
                        $r['patient_name'],
                        $r['doctor_name'],
                        $r['specialization_name'],
                        $r['appt_date'],
                        $r['appt_time'],
                        $r['status'],
                        $r['reason'],
                    ]);
                }
                fclose($out);
                exit;
            }
        }

        $doctorDropdown = $this->doctors->getAll();
        require __DIR__ . '/../views/reports/index.php';
    }
}
