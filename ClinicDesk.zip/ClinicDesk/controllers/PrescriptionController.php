<?php

require_once __DIR__ . '/../models/PrescriptionModel.php';
require_once __DIR__ . '/../models/AppointmentModel.php';
require_once __DIR__ . '/../models/DoctorModel.php';

class PrescriptionController
{
    private PrescriptionModel $prescriptions;
    private AppointmentModel $appointments;
    private DoctorModel $doctors;

    public function __construct()
    {
        $this->prescriptions = new PrescriptionModel();
        $this->appointments = new AppointmentModel();
        $this->doctors = new DoctorModel();
    }

    public function handle(string $action): void
    {
        if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            Auth::requireRole('doctor');
            $this->addGet();
            return;
        }

        if ($action === 'store' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            Auth::requireRole('doctor');
            $this->storePost();
            return;
        }

        if ($action === 'download' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            Auth::requireRole('admin', 'doctor', 'patient');
            $this->downloadGet();
            return;
        }

        if ($action === 'list' || $action === 'index') {
            Auth::requireRole('patient');
            $this->listPatient();
            return;
        }

        flash('warning', 'Unknown prescription action.');
        redirect('index.php?page=dashboard');
    }

    private function addGet(): void
    {
        $apptId = (int) ($_GET['appointment_id'] ?? 0);
        $a = $this->appointments->findById($apptId);
        if ($a === null) {
            flash('danger', 'Appointment not found.');
            redirect('index.php?page=appointments&action=list');
        }

        $doc = $this->doctors->findByUserId(Auth::id());
        if ($doc === null || (int) $a['doctor_id'] !== (int) $doc['id']) {
            redirect('index.php?page=errors&action=forbidden');
        }
        if ($a['status'] !== 'completed') {
            flash('danger', 'Appointment must be completed first.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }

        $existing = $this->prescriptions->findByAppointmentId($apptId);
        if ($existing !== null) {
            flash('warning', 'Prescription already exists.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }

        $pageTitle = 'Add prescription';
        require __DIR__ . '/../views/prescriptions/add.php';
    }

    private function storePost(): void
    {
        if (!CSRF::validateToken($_POST['csrf_token'] ?? '')) {
            flash('danger', 'Invalid security token.');
            redirect('index.php?page=dashboard');
        }

        $apptId = (int) ($_POST['appointment_id'] ?? 0);
        $a = $this->appointments->findById($apptId);
        if ($a === null) {
            flash('danger', 'Appointment not found.');
            redirect('index.php?page=appointments&action=list');
        }

        $doc = $this->doctors->findByUserId(Auth::id());
        if ($doc === null || (int) $a['doctor_id'] !== (int) $doc['id']) {
            redirect('index.php?page=errors&action=forbidden');
        }
        if ($a['status'] !== 'completed') {
            flash('danger', 'Appointment must be completed.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }
        if ($this->prescriptions->findByAppointmentId($apptId) !== null) {
            flash('warning', 'Prescription already exists.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }

        $diagnosis = sanitize((string) ($_POST['diagnosis'] ?? ''));
        $medications = sanitize((string) ($_POST['medications'] ?? ''));
        $notes = sanitize((string) ($_POST['notes'] ?? ''));
        if ($diagnosis === '' || $medications === '') {
            flash('danger', 'Diagnosis and medications are required.');
            redirect('index.php?page=prescriptions&action=add&appointment_id=' . $apptId);
        }

        $filePath = null;
        if (!empty($_FILES['prescription_file']['name']) && (int) $_FILES['prescription_file']['error'] === UPLOAD_ERR_OK) {
            $saved = $this->handlePdfUpload($apptId, $_FILES['prescription_file']);
            if ($saved === null) {
                flash('danger', 'PDF must be a real PDF file under 3 MB.');
                redirect('index.php?page=prescriptions&action=add&appointment_id=' . $apptId);
            }
            $filePath = $saved;
        }

        $this->prescriptions->create([
            'appointment_id' => $apptId,
            'diagnosis' => $diagnosis,
            'medications' => $medications,
            'notes' => $notes !== '' ? $notes : null,
            'file_path' => $filePath,
        ]);

        flash('success', 'Prescription saved.');
        redirect('index.php?page=appointments&action=detail&id=' . $apptId);
    }

    private function handlePdfUpload(int $apptId, array $file): ?string
    {
        if ($file['size'] > MAX_PRESCRIPTION_BYTES) {
            return null;
        }
        $tmp = $file['tmp_name'];
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmp);
        if ($mime !== 'application/pdf') {
            return null;
        }
        $name = 'prescription_' . $apptId . '_' . time() . '.pdf';
        $destDir = BASE_PATH . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'prescriptions';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        $dest = $destDir . DIRECTORY_SEPARATOR . $name;
        if (!move_uploaded_file($tmp, $dest)) {
            return null;
        }
        return 'public/uploads/prescriptions/' . $name;
    }

    private function downloadGet(): void
    {
        $apptId = (int) ($_GET['id'] ?? 0);
        $a = $this->appointments->findById($apptId);
        if ($a === null) {
            redirect('index.php?page=errors&action=forbidden');
        }

        $role = Auth::role();
        if ($role === 'patient' && (int) $a['patient_id'] !== Auth::id()) {
            redirect('index.php?page=errors&action=forbidden');
        }
        if ($role === 'doctor') {
            $doc = $this->doctors->findByUserId(Auth::id());
            if ($doc === null || (int) $a['doctor_id'] !== (int) $doc['id']) {
                redirect('index.php?page=errors&action=forbidden');
            }
        }

        $rx = $this->prescriptions->findByAppointmentId($apptId);
        if ($rx === null || empty($rx['file_path'])) {
            flash('danger', 'No PDF on file.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }

        $rel = (string) $rx['file_path'];
        $full = BASE_PATH . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $rel);
        if (!is_file($full)) {
            flash('danger', 'File missing on server.');
            redirect('index.php?page=appointments&action=detail&id=' . $apptId);
        }

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="prescription.pdf"');
        readfile($full);
        exit;
    }

    private function listPatient(): void
    {
        $pageTitle = 'My prescriptions';
        $rows = $this->prescriptions->getByPatient(Auth::id());
        require __DIR__ . '/../views/prescriptions/list_patient.php';
    }
}
