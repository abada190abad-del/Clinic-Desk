<?php

class HomeController
{
    public function index(): void
    {
        $pageTitle = APP_NAME . ' - الرئيسية';
        $contentView = __DIR__ . '/../views/home/index.php';
        require __DIR__ . '/../views/layouts/public.php';
    }
}
