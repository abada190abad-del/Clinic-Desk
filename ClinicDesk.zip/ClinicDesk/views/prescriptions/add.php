<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card card-primary">
  <div class="card-header"><h3 class="card-title">Add prescription (appointment #<?= (int)$apptId ?>)</h3></div>
  <form method="post" action="index.php?page=prescriptions&action=store" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <input type="hidden" name="appointment_id" value="<?= (int)$apptId ?>">
    <div class="card-body">
      <div class="form-group">
        <label>Diagnosis</label>
        <textarea class="form-control" name="diagnosis" rows="3" required></textarea>
      </div>
      <div class="form-group">
        <label>Medications</label>
        <textarea class="form-control" name="medications" rows="3" required></textarea>
      </div>
      <div class="form-group">
        <label>Notes</label>
        <textarea class="form-control" name="notes" rows="2"></textarea>
      </div>
      <div class="form-group">
        <label>PDF (optional, max 3MB)</label>
        <input type="file" name="prescription_file" accept="application/pdf">
      </div>
    </div>
    <div class="card-footer">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn btn-default" href="index.php?page=appointments&action=detail&id=<?= (int)$apptId ?>">Back</a>
    </div>
  </form>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
