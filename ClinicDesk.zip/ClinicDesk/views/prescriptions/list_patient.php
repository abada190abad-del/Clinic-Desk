<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-body">
    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>Doctor</th>
          <th>Date</th>
          <th>Diagnosis</th>
          <th>PDF</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r) : ?>
        <tr>
          <td><?= e($r['doctor_name']) ?></td>
          <td><?= e($r['appt_date']) ?></td>
          <td><?= e(strlen((string)$r['diagnosis']) > 80 ? (substr((string)$r['diagnosis'], 0, 77) . '...') : (string)$r['diagnosis']) ?></td>
          <td>
            <?php if (!empty($r['file_path'])) : ?>
              <a class="btn btn-sm btn-secondary" href="index.php?page=prescriptions&action=download&id=<?= (int)$r['appointment_id'] ?>">Download</a>
            <?php else : ?>
              —
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
