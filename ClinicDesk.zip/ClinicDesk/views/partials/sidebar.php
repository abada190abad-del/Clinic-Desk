<?php
$curPage = $_GET['page'] ?? '';
$curAction = $_GET['action'] ?? '';
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="index.php?page=dashboard" class="brand-link">
    <span class="brand-text font-weight-light"><?= e(APP_NAME) ?></span>
  </a>
  <div class="sidebar">
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
        <li class="nav-item">
          <a href="index.php?page=dashboard" class="nav-link <?= $curPage === 'dashboard' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p>
          </a>
        </li>

        <?php if (Auth::role() === 'admin') : ?>
        <li class="nav-item">
          <a href="index.php?page=users&action=list" class="nav-link <?= $curPage === 'users' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-users"></i><p>Users</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="index.php?page=specializations" class="nav-link <?= $curPage === 'specializations' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-stethoscope"></i><p>Specializations</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="index.php?page=doctors&action=list" class="nav-link <?= $curPage === 'doctors' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-user-md"></i><p>Doctors</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="index.php?page=reports" class="nav-link <?= $curPage === 'reports' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-file-csv"></i><p>Reports</p>
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
          <a href="index.php?page=appointments&action=list" class="nav-link <?= $curPage === 'appointments' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-calendar"></i><p>Appointments</p>
          </a>
        </li>

        <?php if (Auth::role() === 'patient') : ?>
        <li class="nav-item">
          <a href="index.php?page=appointments&action=book" class="nav-link <?= ($curPage === 'appointments' && $curAction === 'book') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-plus"></i><p>Book</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="index.php?page=prescriptions&action=list" class="nav-link <?= $curPage === 'prescriptions' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-pills"></i><p>My prescriptions</p>
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
          <a href="index.php?page=profile" class="nav-link <?= $curPage === 'profile' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-id-card"></i><p>My profile</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>
