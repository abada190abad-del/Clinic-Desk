<?php if (!empty($_SESSION['flash'])) : ?>
  <?php $f = $_SESSION['flash']; unset($_SESSION['flash']); ?>
  <div class="alert alert-<?= e($f['type'] ?? 'info') ?> alert-dismissible fade show" role="alert">
    <?= e($f['message'] ?? '') ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
