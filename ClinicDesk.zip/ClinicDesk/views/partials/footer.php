  <footer class="main-footer">
    <strong><?= e(APP_NAME) ?></strong>
  </footer>
</div>

<script src="<?= e(ADMINLTE_WEB) ?>/plugins/jquery/jquery.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/dist/js/adminlte.min.js"></script>
<?php if (!empty($useDataTables)) : ?>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script>
  $(function () {
    $('.datatable').DataTable({
      "paging": false,
      "searching": true,
      "info": false,
      "ordering": true
    });
  });
</script>
<?php endif; ?>
</body>
</html>
