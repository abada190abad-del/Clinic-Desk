  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index.php?page=dashboard" class="nav-link">Dashboard</a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item d-none d-sm-inline-block mr-3">
        <span class="nav-link"><?= e(Auth::currentUser()['name'] ?? '') ?> (<?= e(Auth::role()) ?>)</span>
      </li>
      <li class="nav-item">
        <form action="index.php?page=auth&action=logout" method="post" class="form-inline">
          <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
          <button type="submit" class="btn btn-outline-secondary btn-sm">Logout</button>
        </form>
      </li>
    </ul>
  </nav>
