<div x-data="clinicChat()" x-init="init()" class="clinic-chat">
    <button class="chat-fab btn btn-primary rounded-circle shadow" @click="open = !open" aria-label="المساعد">
        <i class="bi" :class="open ? 'bi-x-lg' : 'bi-chat-dots-fill'"></i>
    </button>

    <div class="chat-box card border-0 shadow rounded-4" x-show="open" x-transition style="display:none;">
        <div class="card-header bg-primary text-white rounded-top-4 d-flex align-items-center gap-2">
            <span class="brand-dot bg-white"></span>
            <div>
                <div class="fw-bold small">مساعد <?= e(APP_NAME) ?></div>
                <div class="small opacity-75" style="font-size:.72rem">احجز موعداً أو اسأل عن العيادة</div>
            </div>
        </div>

        <div class="card-body chat-body" x-ref="body">
            <template x-for="(m, i) in messages" :key="i">
                <div class="d-flex mb-2" :class="m.role === 'user' ? 'justify-content-start' : 'justify-content-end'">
                    <div class="chat-bubble small"
                         :class="m.role === 'user' ? 'bubble-user' : 'bubble-bot'"
                         x-text="m.content"></div>
                </div>
            </template>
            <div class="text-muted small" x-show="loading">يكتب…</div>
        </div>

        <div class="card-footer bg-white border-0">
            <form class="d-flex gap-2" @submit.prevent="send()">
                <input class="form-control rounded-pill" x-model="draft"
                       placeholder="اكتب رسالتك…" :disabled="loading" required>
                <button class="btn btn-primary rounded-circle" :disabled="loading" type="submit">
                    <i class="bi bi-send"></i>
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function clinicChat() {
    return {
        open: false,
        loading: false,
        draft: '',
        messages: [
            { role: 'assistant', content: 'مرحباً 👋 أنا مساعد <?= e(APP_NAME) ?>.\nاكتب «حجز موعد» لحجز موعد جديد، أو اسألني عن أوقات الدوام والأطباء.' }
        ],
        init() {
            window.addEventListener('open-clinic-chat', () => { this.open = true; });
        },
        async send() {
            const text = this.draft.trim();
            if (!text || this.loading) return;
            this.messages.push({ role: 'user', content: text });
            this.draft = '';
            this.loading = true;
            this.scroll();

            const history = this.messages.slice(-9, -1).map(m => ({ role: m.role, content: m.content }));

            try {
                const res = await fetch('index.php?page=chatbot&action=message', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ message: text, history }),
                });
                const data = await res.json();
                this.messages.push({ role: 'assistant', content: data.reply || 'حدث خطأ، حاول مجدداً.' });
            } catch (e) {
                this.messages.push({ role: 'assistant', content: 'تعذّر الاتصال، حاول مرة أخرى.' });
            } finally {
                this.loading = false;
                this.scroll();
            }
        },
        scroll() {
            this.$nextTick(() => {
                const b = this.$refs.body;
                if (b) b.scrollTop = b.scrollHeight;
            });
        }
    }
}
</script>
