<?php
if (!isset($pageTitle)) {
    $pageTitle = APP_NAME;
}
if (!isset($csrfToken)) {
    $csrfToken = CSRF::generateToken();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/dist/css/adminlte.min.css">
  <?php if (!empty($useDataTables)) : ?>
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <?php endif; ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
