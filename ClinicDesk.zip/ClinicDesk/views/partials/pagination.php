<?php
/** @var Paginator $paginator */
/** @var string $query */
?>
<?php if ($paginator->totalPages() > 1) : ?>
<nav>
  <ul class="pagination">
    <li class="page-item <?= $paginator->hasPrev() ? '' : 'disabled' ?>">
      <a class="page-link" href="?<?= e($query) ?>&p=<?= $paginator->currentPage() - 1 ?>">Prev</a>
    </li>
    <li class="page-item disabled">
      <span class="page-link">Page <?= (int) $paginator->currentPage() ?> / <?= (int) $paginator->totalPages() ?></span>
    </li>
    <li class="page-item <?= $paginator->hasNext() ? '' : 'disabled' ?>">
      <a class="page-link" href="?<?= e($query) ?>&p=<?= $paginator->currentPage() + 1 ?>">Next</a>
    </li>
  </ul>
</nav>
<?php endif; ?>
