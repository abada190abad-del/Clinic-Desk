<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-body">
    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>Doctor</th>
          <th>Email</th>
          <th>Specialization</th>
          <th>Fee</th>
          <th>Days</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $d) : ?>
        <tr>
          <td><?= e($d['user_name']) ?></td>
          <td><?= e($d['email']) ?></td>
          <td><?= e($d['specialization_name']) ?></td>
          <td><?= e((string)$d['consultation_fee']) ?></td>
          <td><?= e($d['available_days']) ?></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=doctors&action=edit&id=<?= (int)$d['id'] ?>">Edit</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php require __DIR__ . '/../partials/pagination.php'; ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
