<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-header"><h3 class="card-title">Edit doctor</h3></div>
  <form method="post" action="index.php?page=doctors&action=update" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
    <div class="card-body">
      <?php if (Auth::role() === 'admin') : ?>
      <div class="form-group">
        <label>Specialization</label>
        <select class="form-control" name="specialization_id" required>
          <?php foreach ($specs as $s) : ?>
            <option value="<?= (int)$s['id'] ?>" <?= ((int)$d['specialization_id']===(int)$s['id'])?'selected':'' ?>><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <?php else : ?>
        <input type="hidden" name="specialization_id" value="<?= (int)$d['specialization_id'] ?>">
      <?php endif; ?>

      <div class="form-group">
        <label>Consultation fee</label>
        <input class="form-control" type="number" step="0.01" name="consultation_fee" value="<?= e((string)$d['consultation_fee']) ?>" required>
      </div>
      <div class="form-group">
        <label>Bio</label>
        <textarea class="form-control" name="bio" rows="4"><?= e((string)$d['bio']) ?></textarea>
      </div>
      <div class="form-group">
        <label>Available days</label><br>
        <?php
        $picked = explode(',', (string)$d['available_days']);
        $days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        foreach ($days as $day) :
        ?>
          <label class="mr-2"><input type="checkbox" name="available_days[]" value="<?= e($day) ?>" <?= in_array($day, $picked, true)?'checked':'' ?>> <?= e($day) ?></label>
        <?php endforeach; ?>
      </div>
      <div class="form-group">
        <label>Photo</label>
        <input type="file" name="doctor_photo" accept="image/*">
        <?php if (!empty($d['photo'])) : ?>
          <div class="mt-2"><img src="<?= e($d['photo']) ?>" style="max-height:100px;"></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="card-footer">
      <button class="btn btn-primary" type="submit">Save</button>
      <?php if (Auth::role() === 'admin') : ?>
        <a class="btn btn-default" href="index.php?page=doctors&action=list">Back</a>
      <?php else : ?>
        <a class="btn btn-default" href="index.php?page=profile">Back</a>
      <?php endif; ?>
    </div>
  </form>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
