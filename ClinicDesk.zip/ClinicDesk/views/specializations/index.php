<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="row">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header"><h3 class="card-title">Add specialization</h3></div>
      <form method="post" action="index.php?page=specializations&action=store">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <div class="card-body">
          <input class="form-control" name="name" placeholder="Name" required>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary" type="submit">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3 class="card-title">All specializations</h3></div>
  <div class="card-body">
    <table class="table table-bordered">
      <thead><tr><th>ID</th><th>Name</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($list as $row) : ?>
        <tr>
          <td><?= (int)$row['id'] ?></td>
          <td><?= e($row['name']) ?></td>
          <td>
            <form method="post" action="index.php?page=specializations&action=delete" onsubmit="return confirm('Delete?');">
              <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
              <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
