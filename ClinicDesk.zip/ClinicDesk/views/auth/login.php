<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo"><b><?= e(APP_NAME) ?></b></div>
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in</p>
      <?php require __DIR__ . '/../partials/alerts.php'; ?>
      <form action="index.php?page=auth&action=login" method="post">
        <input type="hidden" name="csrf_token" value="<?= e(CSRF::generateToken()) ?>">
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
          <div class="input-group-append"><div class="input-group-text"><span class="fas fa-envelope"></span></div></div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
          <div class="input-group-append"><div class="input-group-text"><span class="fas fa-lock"></span></div></div>
        </div>
        <div class="row">
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block">Sign in</button>
          </div>
        </div>
      </form>
      <div class="text-center mt-3">
        <a href="index.php" class="text-muted">
          <i class="fas fa-arrow-left mr-1"></i>العودة للصفحة الرئيسية
        </a>
      </div>
    </div>
  </div>
</div>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/jquery/jquery.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/dist/js/adminlte.min.js"></script>
</body>
</html>
