<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Change password | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo"><b>Change password</b></div>
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">You must set a new password</p>
      <?php require __DIR__ . '/../partials/alerts.php'; ?>
      <form action="index.php?page=auth&action=change_password" method="post">
        <input type="hidden" name="csrf_token" value="<?= e(CSRF::generateToken()) ?>">
        <div class="input-group mb-3">
          <input type="password" name="current_password" class="form-control" placeholder="Current password" required>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="new_password" class="form-control" placeholder="New password" required>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Save</button>
      </form>
    </div>
  </div>
</div>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/jquery/jquery.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(ADMINLTE_WEB) ?>/dist/js/adminlte.min.js"></script>
</body>
</html>
