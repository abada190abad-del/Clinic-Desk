<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card card-primary">
  <div class="card-header"><h3 class="card-title">Book appointment</h3></div>
  <form method="post" action="index.php?page=appointments&action=book">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <div class="card-body">
      <div class="form-group">
        <label>Doctor</label>
        <select class="form-control" name="doctor_id" id="doctor_id" required>
          <option value="">-- choose --</option>
          <?php foreach ($doctorList as $doc) : ?>
            <option value="<?= (int)$doc['id'] ?>" data-days="<?= e($doc['available_days']) ?>">
              <?= e($doc['doctor_name']) ?> — <?= e($doc['specialization_name']) ?> ($<?= e((string)$doc['consultation_fee']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
        <small class="form-text text-muted" id="days_hint"></small>
      </div>
      <div class="form-group">
        <label>Date</label>
        <input class="form-control" type="date" name="appt_date" required>
      </div>
      <div class="form-group">
        <label>Time</label>
        <select class="form-control" name="appt_time" required>
          <?php foreach ($slots as $t) : ?>
            <option value="<?= e($t) ?>"><?= e($t) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Reason</label>
        <input class="form-control" name="reason" maxlength="255">
      </div>
    </div>
    <div class="card-footer">
      <button class="btn btn-primary" type="submit">Book</button>
    </div>
  </form>
</div>
<script>
(function () {
  var sel = document.getElementById('doctor_id');
  var hint = document.getElementById('days_hint');
  function updateHint() {
    var opt = sel.options[sel.selectedIndex];
    var days = opt ? opt.getAttribute('data-days') : '';
    hint.textContent = days ? ('Available weekdays: ' + days) : '';
  }
  sel.addEventListener('change', updateHint);
  updateHint();
})();
</script>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
