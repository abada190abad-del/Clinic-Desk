<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-body">
    <form class="mb-3" method="get">
      <input type="hidden" name="page" value="appointments">
      <input type="hidden" name="action" value="list">
      <div class="row">
        <div class="col-md-3">
          <select class="form-control" name="status">
            <option value="">All statuses</option>
            <option value="pending" <?= ($filters['status']==='pending')?'selected':'' ?>>Pending</option>
            <option value="confirmed" <?= ($filters['status']==='confirmed')?'selected':'' ?>>Confirmed</option>
            <option value="completed" <?= ($filters['status']==='completed')?'selected':'' ?>>Completed</option>
            <option value="cancelled" <?= ($filters['status']==='cancelled')?'selected':'' ?>>Cancelled</option>
          </select>
        </div>
        <div class="col-md-3"><input class="form-control" type="date" name="date_from" value="<?= e($filters['date_from']) ?>"></div>
        <div class="col-md-3"><input class="form-control" type="date" name="date_to" value="<?= e($filters['date_to']) ?>"></div>
        <div class="col-md-2"><button class="btn btn-secondary btn-block" type="submit">Filter</button></div>
      </div>
    </form>

    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>Doctor</th>
          <th>Spec</th>
          <th>Date</th>
          <th>Time</th>
          <th>Status</th>
          <th>Reason</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $a) : ?>
        <tr>
          <td><?= e($a['doctor_name']) ?></td>
          <td><?= e($a['specialization_name']) ?></td>
          <td><?= e($a['appt_date']) ?></td>
          <td><?= e(formatTime($a['appt_time'])) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($a['status'])) ?>"><?= e($a['status']) ?></span></td>
          <td><?= e((string)$a['reason']) ?></td>
          <td>
            <a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$a['id'] ?>">View</a>
            <?php if ($a['status'] === 'completed' && !empty($a['prescription_id'])) : ?>
              <a class="btn btn-sm btn-secondary" href="index.php?page=prescriptions&action=download&id=<?= (int)$a['id'] ?>">PDF</a>
            <?php endif; ?>
            <?php if ($a['status'] === 'pending') : ?>
            <form style="display:inline" method="post" action="index.php?page=appointments&action=cancel" onsubmit="return confirm('Cancel?');">
              <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
              <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit">Cancel</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php
    $query = http_build_query(['page'=>'appointments','action'=>'list','status'=>$filters['status'],'date_from'=>$filters['date_from'],'date_to'=>$filters['date_to']]);
    require __DIR__ . '/../partials/pagination.php';
    ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
