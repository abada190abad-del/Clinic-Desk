<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';

$role = Auth::role();
?>
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Appointment #<?= (int)$a['id'] ?></h3>
  </div>
  <div class="card-body">
    <p><strong>Patient:</strong> <?= e($a['patient_name']) ?> (<?= e($a['patient_email']) ?>)</p>
    <p><strong>Doctor:</strong> <?= e($a['doctor_name']) ?> — <?= e($a['specialization_name']) ?></p>
    <p><strong>When:</strong> <?= e($a['appt_date']) ?> <?= e(formatTime($a['appt_time'])) ?></p>
    <p><strong>Status:</strong> <span class="badge badge-<?= e(badge_class_for_status($a['status'])) ?>"><?= e($a['status']) ?></span></p>
    <p><strong>Reason:</strong> <?= e((string)$a['reason']) ?></p>
    <p><strong>Doctor notes:</strong><br><?= nl2br(e((string)$a['doctor_notes'])) ?></p>

    <?php if ($rx) : ?>
      <hr>
      <h5>Prescription</h5>
      <p><strong>Diagnosis:</strong> <?= nl2br(e($rx['diagnosis'])) ?></p>
      <p><strong>Medications:</strong> <?= nl2br(e($rx['medications'])) ?></p>
      <p><strong>Notes:</strong> <?= nl2br(e((string)$rx['notes'])) ?></p>
      <?php if (!empty($rx['file_path'])) : ?>
        <a class="btn btn-sm btn-secondary" href="index.php?page=prescriptions&action=download&id=<?= (int)$a['id'] ?>">Download PDF</a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<?php if ($role === 'doctor') : ?>
  <?php $isMine = $docMine && ((int)$a['doctor_id'] === (int)$docMine['id']); ?>
  <?php if ($isMine) : ?>
    <div class="card">
      <div class="card-header"><h3 class="card-title">Update notes</h3></div>
      <form method="post" action="index.php?page=appointments&action=save_notes">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
        <div class="card-body">
          <textarea class="form-control" name="doctor_notes" rows="4"><?= e((string)$a['doctor_notes']) ?></textarea>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary" type="submit">Save notes</button>
        </div>
      </form>
    </div>

    <div class="card">
      <div class="card-header"><h3 class="card-title">Status</h3></div>
      <div class="card-body">
        <?php if ($a['status'] === 'pending') : ?>
          <form method="post" action="index.php?page=appointments&action=set_status" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <input type="hidden" name="status" value="confirmed">
            <button class="btn btn-info" type="submit">Confirm</button>
          </form>
          <form method="post" action="index.php?page=appointments&action=set_status" class="d-inline" onsubmit="return confirm('Cancel appointment?');">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <input type="hidden" name="status" value="cancelled">
            <button class="btn btn-danger" type="submit">Cancel</button>
          </form>
        <?php endif; ?>

        <?php if ($a['status'] === 'confirmed') : ?>
          <form method="post" action="index.php?page=appointments&action=set_status" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <input type="hidden" name="status" value="completed">
            <button class="btn btn-success" type="submit">Complete</button>
          </form>
          <form method="post" action="index.php?page=appointments&action=set_status" class="d-inline" onsubmit="return confirm('Cancel appointment?');">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <input type="hidden" name="status" value="cancelled">
            <button class="btn btn-danger" type="submit">Cancel</button>
          </form>
        <?php endif; ?>

        <?php if ($a['status'] === 'completed' && !$rx) : ?>
          <a class="btn btn-primary" href="index.php?page=prescriptions&action=add&appointment_id=<?= (int)$a['id'] ?>">Add prescription</a>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>
<?php endif; ?>

<?php if ($role === 'admin') : ?>
<div class="card">
  <div class="card-header"><h3 class="card-title">Admin: set status</h3></div>
  <form method="post" action="index.php?page=appointments&action=set_status">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
    <div class="card-body">
      <select class="form-control" name="status">
        <?php foreach (['pending','confirmed','completed','cancelled'] as $st) : ?>
          <option value="<?= e($st) ?>" <?= ($a['status']===$st)?'selected':'' ?>><?= e($st) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="card-footer">
      <button class="btn btn-warning" type="submit">Update status</button>
    </div>
  </form>
</div>
<?php endif; ?>

<?php if ($role === 'patient' && (int)$a['patient_id'] === Auth::id() && $a['status'] === 'pending') : ?>
<div class="card">
  <div class="card-body">
    <form method="post" action="index.php?page=appointments&action=cancel" onsubmit="return confirm('Cancel?');">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
      <button class="btn btn-danger" type="submit">Cancel appointment</button>
    </form>
  </div>
</div>
<?php endif; ?>

<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
