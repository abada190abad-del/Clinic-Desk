<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-body">
    <form class="mb-3" method="get">
      <input type="hidden" name="page" value="appointments">
      <input type="hidden" name="action" value="list">
      <div class="row">
        <div class="col-md-3">
          <select class="form-control" name="doctor_id">
            <option value="0">All doctors</option>
            <?php foreach ($doctorDropdown as $dd) : ?>
              <option value="<?= (int)$dd['id'] ?>" <?= ((int)$filters['doctor_id']===(int)$dd['id'])?'selected':'' ?>>
                <?= e($dd['doctor_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3"><input class="form-control" name="patient_search" placeholder="Patient name" value="<?= e($filters['patient_search']) ?>"></div>
        <div class="col-md-2">
          <select class="form-control" name="status">
            <option value="">All statuses</option>
            <option value="pending" <?= ($filters['status']==='pending')?'selected':'' ?>>Pending</option>
            <option value="confirmed" <?= ($filters['status']==='confirmed')?'selected':'' ?>>Confirmed</option>
            <option value="completed" <?= ($filters['status']==='completed')?'selected':'' ?>>Completed</option>
            <option value="cancelled" <?= ($filters['status']==='cancelled')?'selected':'' ?>>Cancelled</option>
          </select>
        </div>
        <div class="col-md-2"><input class="form-control" type="date" name="date_from" value="<?= e($filters['date_from']) ?>"></div>
        <div class="col-md-2"><input class="form-control" type="date" name="date_to" value="<?= e($filters['date_to']) ?>"></div>
      </div>
      <button class="btn btn-secondary mt-2" type="submit">Filter</button>
    </form>

    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>Patient</th>
          <th>Doctor</th>
          <th>Spec</th>
          <th>Date</th>
          <th>Time</th>
          <th>Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $a) : ?>
        <tr>
          <td><?= e($a['patient_name']) ?></td>
          <td><?= e($a['doctor_name']) ?></td>
          <td><?= e($a['specialization_name']) ?></td>
          <td><?= e($a['appt_date']) ?></td>
          <td><?= e(formatTime($a['appt_time'])) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($a['status'])) ?>"><?= e($a['status']) ?></span></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$a['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php
    $query = http_build_query([
      'page'=>'appointments','action'=>'list',
      'doctor_id'=>$filters['doctor_id'],
      'patient_search'=>$filters['patient_search'],
      'status'=>$filters['status'],
      'date_from'=>$filters['date_from'],
      'date_to'=>$filters['date_to'],
    ]);
    require __DIR__ . '/../partials/pagination.php';
    ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
