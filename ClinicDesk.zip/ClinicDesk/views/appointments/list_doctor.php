<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card card-info">
  <div class="card-header"><h3 class="card-title">Today</h3></div>
  <div class="card-body p-0">
    <table class="table mb-0">
      <thead><tr><th>Time</th><th>Patient</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php if (count($todayRows) === 0) : ?>
          <tr><td colspan="4" class="p-3">No appointments today.</td></tr>
        <?php endif; ?>
        <?php foreach ($todayRows as $t) : ?>
        <tr>
          <td><?= e(formatTime($t['appt_time'])) ?></td>
          <td><?= e($t['patient_name']) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($t['status'])) ?>"><?= e($t['status']) ?></span></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$t['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card mt-3">
  <div class="card-body">
    <form class="mb-3" method="get">
      <input type="hidden" name="page" value="appointments">
      <input type="hidden" name="action" value="list">
      <div class="row">
        <div class="col-md-3">
          <select class="form-control" name="status">
            <option value="">All statuses</option>
            <option value="pending" <?= ($filters['status']==='pending')?'selected':'' ?>>Pending</option>
            <option value="confirmed" <?= ($filters['status']==='confirmed')?'selected':'' ?>>Confirmed</option>
            <option value="completed" <?= ($filters['status']==='completed')?'selected':'' ?>>Completed</option>
            <option value="cancelled" <?= ($filters['status']==='cancelled')?'selected':'' ?>>Cancelled</option>
          </select>
        </div>
        <div class="col-md-3"><input class="form-control" type="date" name="date_from" value="<?= e($filters['date_from']) ?>"></div>
        <div class="col-md-3"><input class="form-control" type="date" name="date_to" value="<?= e($filters['date_to']) ?>"></div>
        <div class="col-md-2"><button class="btn btn-secondary btn-block" type="submit">Filter</button></div>
      </div>
    </form>

    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>Patient</th>
          <th>Date</th>
          <th>Time</th>
          <th>Status</th>
          <th>Reason</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $a) : ?>
        <tr>
          <td><?= e($a['patient_name']) ?></td>
          <td><?= e($a['appt_date']) ?></td>
          <td><?= e(formatTime($a['appt_time'])) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($a['status'])) ?>"><?= e($a['status']) ?></span></td>
          <td><?= e((string)$a['reason']) ?></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$a['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php
    $query = http_build_query(['page'=>'appointments','action'=>'list','status'=>$filters['status'],'date_from'=>$filters['date_from'],'date_to'=>$filters['date_to']]);
    require __DIR__ . '/../partials/pagination.php';
    ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
