<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card card-primary">
  <div class="card-header"><h3 class="card-title">New user</h3></div>
  <form method="post" action="index.php?page=users&action=store">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <div class="card-body">
      <div class="form-group">
        <label>Name</label>
        <input class="form-control" name="name" required>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" type="email" name="email" required>
      </div>
      <div class="form-group">
        <label>Temporary password</label>
        <input class="form-control" type="text" name="temp_password" required>
      </div>
      <div class="form-group">
        <label>Phone</label>
        <input class="form-control" name="phone">
      </div>
      <div class="form-group">
        <label>Role</label>
        <select class="form-control" name="role" id="role_select">
          <option value="patient">Patient</option>
          <option value="doctor">Doctor</option>
          <option value="admin">Admin</option>
        </select>
      </div>

      <div id="doctor_block" style="display:none;">
        <hr>
        <h5>Doctor details</h5>
        <div class="form-group">
          <label>Specialization</label>
          <select class="form-control" name="specialization_id">
            <option value="0">-- pick --</option>
            <?php foreach ($specs as $s) : ?>
              <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Consultation fee</label>
          <input class="form-control" type="number" step="0.01" name="consultation_fee" value="0">
        </div>
        <div class="form-group">
          <label>Bio</label>
          <textarea class="form-control" name="bio" rows="3"></textarea>
        </div>
        <div class="form-group">
          <label>Available days</label><br>
          <?php $days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']; ?>
          <?php foreach ($days as $d) : ?>
            <label class="mr-2"><input type="checkbox" name="available_days[]" value="<?= e($d) ?>"> <?= e($d) ?></label>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div class="card-footer">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn btn-default" href="index.php?page=users&action=list">Cancel</a>
    </div>
  </form>
</div>
<script>
document.getElementById('role_select').addEventListener('change', function () {
  document.getElementById('doctor_block').style.display = (this.value === 'doctor') ? 'block' : 'none';
});
</script>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
