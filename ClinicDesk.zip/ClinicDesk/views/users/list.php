<?php
$useDataTables = true;
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-header">
    <a href="index.php?page=users&action=create" class="btn btn-primary btn-sm">Create user</a>
  </div>
  <div class="card-body">
    <form method="get" class="mb-3">
      <input type="hidden" name="page" value="users">
      <input type="hidden" name="action" value="list">
      <div class="row">
        <div class="col-md-3">
          <select name="role" class="form-control">
            <option value="">All roles</option>
            <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
            <option value="doctor" <?= $role === 'doctor' ? 'selected' : '' ?>>Doctor</option>
            <option value="patient" <?= $role === 'patient' ? 'selected' : '' ?>>Patient</option>
          </select>
        </div>
        <div class="col-md-4">
          <input type="text" name="q" class="form-control" placeholder="Search name/email" value="<?= e($search) ?>">
        </div>
        <div class="col-md-2">
          <button class="btn btn-secondary btn-block" type="submit">Filter</button>
        </div>
      </div>
    </form>

    <table class="table table-bordered datatable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Active</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $u) : ?>
        <tr>
          <td><?= (int) $u['id'] ?></td>
          <td><?= e($u['name']) ?></td>
          <td><?= e($u['email']) ?></td>
          <td><?= e($u['role']) ?></td>
          <td><?= ((int)$u['is_active'] === 1) ? 'Yes' : 'No' ?></td>
          <td>
            <a class="btn btn-sm btn-info" href="index.php?page=users&action=edit&id=<?= (int)$u['id'] ?>">Edit</a>
            <?php if ((int)$u['id'] !== Auth::id()) : ?>
            <form action="index.php?page=users&action=toggle" method="post" style="display:inline;">
              <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
              <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
              <button type="submit" class="btn btn-sm btn-warning">Toggle active</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <?php require __DIR__ . '/../partials/pagination.php'; ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
