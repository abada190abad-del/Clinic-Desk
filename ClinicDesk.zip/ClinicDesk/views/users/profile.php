<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="card">
  <div class="card-header"><h3 class="card-title">My profile</h3></div>
  <form method="post" action="index.php?page=profile&action=update" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
    <div class="card-body">
      <div class="form-group">
        <label>Name</label>
        <input class="form-control" name="name" value="<?= e($u['name']) ?>" required>
      </div>
      <div class="form-group">
        <label>Phone</label>
        <input class="form-control" name="phone" value="<?= e((string)$u['phone']) ?>">
      </div>
      <div class="form-group">
        <label>Avatar</label>
        <input type="file" name="avatar" accept="image/*">
        <?php if (!empty($u['avatar'])) : ?>
          <div class="mt-2"><img src="<?= e($u['avatar']) ?>" alt="" style="max-height:80px;"></div>
        <?php endif; ?>
      </div>

      <?php if ($doctor) : ?>
        <hr>
        <h5>Doctor info</h5>
        <div class="form-group">
          <label>Bio</label>
          <textarea class="form-control" name="bio" rows="3"><?= e((string)$doctor['bio']) ?></textarea>
        </div>
        <div class="form-group">
          <label>Fee</label>
          <input class="form-control" type="number" step="0.01" name="consultation_fee" value="<?= e((string)$doctor['consultation_fee']) ?>">
        </div>
        <div class="form-group">
          <label>Available days</label><br>
          <?php
          $picked = explode(',', (string)$doctor['available_days']);
          $days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
          foreach ($days as $d) :
          ?>
            <label class="mr-2"><input type="checkbox" name="available_days[]" value="<?= e($d) ?>" <?= in_array($d, $picked, true)?'checked':'' ?>> <?= e($d) ?></label>
          <?php endforeach; ?>
        </div>
        <div class="form-group">
          <label>Doctor photo</label>
          <input type="file" name="doctor_photo" accept="image/*">
          <?php if (!empty($doctor['photo'])) : ?>
            <div class="mt-2"><img src="<?= e($doctor['photo']) ?>" alt="" style="max-height:80px;"></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
    <div class="card-footer">
      <button class="btn btn-primary" type="submit">Save</button>
    </div>
  </form>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
