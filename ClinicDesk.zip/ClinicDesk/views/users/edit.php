<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="row">
  <div class="col-md-8">
    <div class="card">
      <div class="card-header"><h3 class="card-title">Edit user</h3></div>
      <form method="post" action="index.php?page=users&action=update" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
        <div class="card-body">
          <div class="form-group">
            <label>Name</label>
            <input class="form-control" name="name" value="<?= e($u['name']) ?>" required>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input class="form-control" value="<?= e($u['email']) ?>" disabled>
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input class="form-control" name="phone" value="<?= e((string)$u['phone']) ?>">
          </div>
          <div class="form-group">
            <label>Avatar (JPEG/PNG, max 1MB)</label>
            <input type="file" name="avatar" accept="image/*">
            <?php if (!empty($u['avatar'])) : ?>
              <div class="mt-2"><img src="<?= e($u['avatar']) ?>" alt="" style="max-height:80px;"></div>
            <?php endif; ?>
          </div>
          <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="is_active" id="is_active" <?= ((int)$u['is_active']===1)?'checked':'' ?>>
            <label class="form-check-label" for="is_active">Active</label>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary" type="submit">Save</button>
          <a class="btn btn-default" href="index.php?page=users&action=list">Back</a>
        </div>
      </form>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card">
      <div class="card-header"><h3 class="card-title">Reset password</h3></div>
      <form method="post" action="index.php?page=users&action=reset_password">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
        <div class="card-body">
          <input class="form-control" type="text" name="new_password" placeholder="New password" required>
        </div>
        <div class="card-footer">
          <button class="btn btn-warning btn-sm" type="submit">Reset</button>
        </div>
      </form>
    </div>
    <?php if ($u['role'] === 'doctor' && $doctor) : ?>
      <a class="btn btn-info btn-block mt-2" href="index.php?page=doctors&action=edit&id=<?= (int)$doctor['id'] ?>">Edit doctor record</a>
    <?php endif; ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
