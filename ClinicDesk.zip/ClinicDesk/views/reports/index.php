<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';

$start = $start ?? '';
$end = $end ?? '';
$doctorId = $doctorId ?? 0;
$status = $status ?? '';
$patientSearch = $patientSearch ?? '';
?>
<div class="card">
  <div class="card-header"><h3 class="card-title">Appointment report</h3></div>
  <div class="card-body">
    <form method="get" class="mb-3">
      <input type="hidden" name="page" value="reports">
      <div class="row">
        <div class="col-md-3">
          <label>Start date</label>
          <input class="form-control" type="date" name="start_date" value="<?= e($start) ?>" required>
        </div>
        <div class="col-md-3">
          <label>End date</label>
          <input class="form-control" type="date" name="end_date" value="<?= e($end) ?>" required>
        </div>
        <div class="col-md-3">
          <label>Doctor</label>
          <select class="form-control" name="doctor_id">
            <option value="0">All</option>
            <?php foreach ($doctorDropdown as $dd) : ?>
              <option value="<?= (int)$dd['id'] ?>" <?= ((int)$doctorId===(int)$dd['id'])?'selected':'' ?>><?= e($dd['doctor_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label>Status</label>
          <select class="form-control" name="status">
            <option value="">All</option>
            <option value="pending" <?= ($status==='pending')?'selected':'' ?>>Pending</option>
            <option value="confirmed" <?= ($status==='confirmed')?'selected':'' ?>>Confirmed</option>
            <option value="completed" <?= ($status==='completed')?'selected':'' ?>>Completed</option>
            <option value="cancelled" <?= ($status==='cancelled')?'selected':'' ?>>Cancelled</option>
          </select>
        </div>
      </div>
      <div class="row mt-2">
        <div class="col-md-6">
          <label>Patient name contains</label>
          <input class="form-control" name="patient_search" value="<?= e($patientSearch) ?>">
        </div>
        <div class="col-md-3 d-flex align-items-end">
          <button class="btn btn-primary btn-block" type="submit">Run report</button>
        </div>
      </div>
    </form>

    <?php if ($start !== '' && $end !== '') : ?>
      <a class="btn btn-sm btn-secondary mb-2"
         href="index.php?<?= e(http_build_query([
           'page'=>'reports',
           'export'=>'csv',
           'start_date'=>$start,
           'end_date'=>$end,
           'doctor_id'=>$doctorId,
           'status'=>$status,
           'patient_search'=>$patientSearch,
         ])) ?>">Export CSV</a>

      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Patient</th><th>Doctor</th><th>Spec</th><th>Date</th><th>Time</th><th>Status</th><th>Reason</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r) : ?>
          <tr>
            <td><?= e($r['patient_name']) ?></td>
            <td><?= e($r['doctor_name']) ?></td>
            <td><?= e($r['specialization_name']) ?></td>
            <td><?= e($r['appt_date']) ?></td>
            <td><?= e(formatTime($r['appt_time'])) ?></td>
            <td><span class="badge badge-<?= e(badge_class_for_status($r['status'])) ?>"><?= e($r['status']) ?></span></td>
            <td><?= e((string)$r['reason']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="7"><strong>Total rows:</strong> <?= (int)$summary['total'] ?> —
              <?php foreach ($summary['by_status'] as $st => $cnt) : ?>
                <?= e($st) ?>: <?= (int)$cnt ?>;
              <?php endforeach; ?>
            </td>
          </tr>
        </tfoot>
      </table>
    <?php else : ?>
      <p class="text-muted">Pick a date range and click “Run report”.</p>
    <?php endif; ?>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
