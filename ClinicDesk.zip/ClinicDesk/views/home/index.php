<?php
$isLoggedIn = Auth::check();
?>
<div class="hero-wrap p-4 p-lg-5 mb-4">
    <div class="row align-items-center g-4">
        <div class="col-lg-6">
            <span class="badge text-bg-light rounded-pill px-3 py-2 mb-3 soft-shadow">
                <i class="bi bi-shield-check ms-1"></i>حجز آمن + تذكيرات + سجل استشارات
            </span>
            <h1 class="display-5 fw-bold lh-sm mb-3">
                احجز موعدك في <span class="text-gradient"><?= e(APP_NAME) ?></span> خلال دقيقة
            </h1>
            <p class="text-muted fs-5 mb-4">
                منصة أنيقة لحجز المواعيد وإدارة الاستشارات: جدول الطبيب، متابعة الطلبات، وتاريخ المواعيد — وكل شيء مرتب.
            </p>

            <div class="d-flex flex-wrap gap-2">
                <?php if (!$isLoggedIn): ?>
                    <button type="button" class="btn btn-primary btn-lg rounded-pill px-4" onclick="window.dispatchEvent(new CustomEvent('open-clinic-chat'))">
                        احجز عبر المساعد <i class="bi bi-chat-dots ms-1"></i>
                    </button>
                    <a class="btn btn-outline-dark btn-lg rounded-pill px-4" href="index.php?page=auth&action=login">
                        تسجيل دخول
                    </a>
                <?php else: ?>
                    <a class="btn btn-primary btn-lg rounded-pill px-4" href="index.php?page=dashboard">
                        دخول لوحة التحكم <i class="bi bi-arrow-left-short"></i>
                    </a>
                    <a class="btn btn-outline-dark btn-lg rounded-pill px-4" href="index.php?page=appointments&action=book">
                        حجز موعد
                    </a>
                <?php endif; ?>
            </div>

            <div class="mt-4 d-flex flex-wrap gap-3">
                <div class="mini-stat">
                    <i class="bi bi-calendar2-week"></i>
                    <div>
                        <div class="fw-bold">جدولة ذكية</div>
                        <div class="text-muted small">مواعيد منظمة وحالة واضحة</div>
                    </div>
                </div>
                <div class="mini-stat">
                    <i class="bi bi-chat-left-dots"></i>
                    <div>
                        <div class="fw-bold">مساعد ذكي</div>
                        <div class="text-muted small">احجز موعدك من المحادثة مباشرة</div>
                    </div>
                </div>
                <div class="mini-stat">
                    <i class="bi bi-file-medical"></i>
                    <div>
                        <div class="fw-bold">سجل الطلبات</div>
                        <div class="text-muted small">ترجع لأي طلب بسهولة</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="hero-card soft-shadow">
                <img class="w-100 rounded-4" src="public/assets/landing/img/clinic-hero.jpg" alt="Clinic">
                <div class="p-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="fw-bold">عيادة متكاملة</div>
                            <div class="text-muted small">استقبال — متابعة — حجز — استشارات</div>
                        </div>
                        <span class="badge text-bg-primary rounded-pill px-3 py-2">VIP Care</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <div class="feature-card p-4 soft-shadow">
            <div class="icon-bubble"><i class="bi bi-clock-history"></i></div>
            <h5 class="fw-bold mt-3">تذكير وتنظيم</h5>
            <p class="text-muted mb-0">اطلع على الطلبات وحالتها: قيد الانتظار، مؤكد، مكتمل.</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="feature-card p-4 soft-shadow">
            <div class="icon-bubble"><i class="bi bi-person-check"></i></div>
            <h5 class="fw-bold mt-3">لوحة للطبيب</h5>
            <p class="text-muted mb-0">تأكيد المواعيد، إضافة ملاحظات، وإدارة الجدول اليومي.</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="feature-card p-4 soft-shadow">
            <div class="icon-bubble"><i class="bi bi-lock"></i></div>
            <h5 class="fw-bold mt-3">صلاحيات واضحة</h5>
            <p class="text-muted mb-0">مريض للحجز والمتابعة، وطبيب وإدارة لإدارة العيادة.</p>
        </div>
    </div>
</div>
