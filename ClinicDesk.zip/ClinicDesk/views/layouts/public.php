<?php
/** @var string $pageTitle */
$csrfToken = CSRF::generateToken();
$isLoggedIn = Auth::check();
$currentUser = Auth::currentUser();
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e($csrfToken) ?>">
    <title><?= e($pageTitle ?? APP_NAME) ?></title>

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.10/dist/cdn.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/assets/landing/style.css">
</head>
<body class="bg-soft">

<nav class="navbar navbar-expand-lg glass-nav py-3">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="index.php?page=home">
            <span class="brand-dot"></span>
            <span><?= e(APP_NAME) ?></span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div id="nav" class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-lg-2">
                <li class="nav-item"><a class="nav-link" href="index.php?page=home">الرئيسية</a></li>
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item"><a class="nav-link" href="index.php?page=dashboard">لوحة التحكم</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php?page=appointments&action=list">المواعيد</a></li>
                <?php endif; ?>
            </ul>

            <div class="d-flex gap-2">
                <?php if (!$isLoggedIn): ?>
                    <a class="btn btn-outline-dark rounded-pill px-3" href="index.php?page=auth&action=login">
                        <i class="bi bi-box-arrow-in-left ms-1"></i>تسجيل دخول
                    </a>
                <?php else: ?>
                    <span class="btn btn-light rounded-pill px-3 disabled border-0">
                        <i class="bi bi-person ms-1"></i><?= e($currentUser['name'] ?? '') ?>
                    </span>
                    <a class="btn btn-dark rounded-pill px-3" href="index.php?page=auth&action=logout">
                        <i class="bi bi-door-open ms-1"></i>خروج
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<main class="py-4">
    <div class="container">
        <?php if (!empty($_SESSION['flash'])): ?>
            <?php $f = $_SESSION['flash']; unset($_SESSION['flash']); ?>
            <div class="alert alert-<?= e($f['type'] ?? 'info') ?> soft-shadow border-0 alert-dismissible fade show" role="alert">
                <?= e($f['message'] ?? '') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php require $contentView; ?>
    </div>
</main>

<footer class="py-4 mt-5">
    <div class="container text-center text-muted small">
        © <?= date('Y') ?> <?= e(APP_NAME) ?> — حجز واستشارات بطريقة أنيقة
    </div>
</footer>

<?php require __DIR__ . '/../partials/chatbot.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
