<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="row">
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-info"><i class="fas fa-calendar"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">This month</span>
        <span class="info-box-number"><?= (int)$totalMonth ?></span>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-warning"><i class="fas fa-hourglass-half"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Pending (month)</span>
        <span class="info-box-number"><?= (int)$pendingMonth ?></span>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-success"><i class="fas fa-check"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Completed (month)</span>
        <span class="info-box-number"><?= (int)$completedMonth ?></span>
      </div>
    </div>
  </div>
</div>

<div class="card card-info">
  <div class="card-header"><h3 class="card-title">Today</h3></div>
  <div class="card-body p-0">
    <table class="table mb-0">
      <thead><tr><th>Time</th><th>Patient</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php if (count($today) === 0) : ?>
          <tr><td colspan="4" class="p-3">No appointments today.</td></tr>
        <?php endif; ?>
        <?php foreach ($today as $t) : ?>
        <tr>
          <td><?= e(formatTime($t['appt_time'])) ?></td>
          <td><?= e($t['patient_name']) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($t['status'])) ?>"><?= e($t['status']) ?></span></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$t['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card mt-3">
  <div class="card-header"><h3 class="card-title">Next up</h3></div>
  <div class="card-body p-0">
    <table class="table mb-0">
      <thead><tr><th>Date</th><th>Time</th><th>Patient</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($upcoming as $u) : ?>
        <tr>
          <td><?= e($u['appt_date']) ?></td>
          <td><?= e(formatTime($u['appt_time'])) ?></td>
          <td><?= e($u['patient_name']) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($u['status'])) ?>"><?= e($u['status']) ?></span></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$u['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
