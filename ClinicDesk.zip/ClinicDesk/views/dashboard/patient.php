<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';
?>
<div class="row">
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-warning"><i class="fas fa-notes-medical"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Active appointments</span>
        <span class="info-box-number"><?= (int)$activeCount ?></span>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-success"><i class="fas fa-check"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Completed</span>
        <span class="info-box-number"><?= (int)$completedCount ?></span>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="info-box">
      <span class="info-box-icon bg-info"><i class="fas fa-pills"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Prescriptions</span>
        <span class="info-box-number"><?= (int)$rxCount ?></span>
      </div>
    </div>
  </div>
</div>

<?php if ($next) : ?>
<div class="card card-primary">
  <div class="card-header"><h3 class="card-title">Next appointment</h3></div>
  <div class="card-body">
    <p><strong>Doctor:</strong> <?= e($next['doctor_name']) ?> (<?= e($next['specialization_name']) ?>)</p>
    <p><strong>When:</strong> <?= e($next['appt_date']) ?> <?= e(formatTime($next['appt_time'])) ?></p>
    <p><strong>Status:</strong> <span class="badge badge-<?= e(badge_class_for_status($next['status'])) ?>"><?= e($next['status']) ?></span></p>
    <a class="btn btn-info btn-sm" href="index.php?page=appointments&action=detail&id=<?= (int)$next['id'] ?>">Details</a>
  </div>
</div>
<?php endif; ?>

<div class="card mt-3">
  <div class="card-header"><h3 class="card-title">Active appointments</h3></div>
  <div class="card-body p-0">
    <table class="table mb-0">
      <thead><tr><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php if (count($activeList) === 0) : ?>
          <tr><td colspan="5" class="p-3">None.</td></tr>
        <?php endif; ?>
        <?php foreach ($activeList as $a) : ?>
        <tr>
          <td><?= e($a['doctor_name']) ?></td>
          <td><?= e($a['appt_date']) ?></td>
          <td><?= e(formatTime($a['appt_time'])) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($a['status'])) ?>"><?= e($a['status']) ?></span></td>
          <td><a class="btn btn-sm btn-info" href="index.php?page=appointments&action=detail&id=<?= (int)$a['id'] ?>">Open</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
