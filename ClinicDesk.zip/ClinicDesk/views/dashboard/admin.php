<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../partials/navbar.php';
require_once __DIR__ . '/../partials/sidebar.php';
require_once __DIR__ . '/../partials/content_start.php';

$roleTotals = [];
foreach ($statsRoles as $row) {
    $roleTotals[$row['role']] = (int) $row['total'];
}
?>
<div class="row">
  <div class="col-lg-3 col-6">
    <div class="small-box bg-info">
      <div class="inner"><h3><?= (int)($roleTotals['admin'] ?? 0) ?></h3><p>Admins</p></div>
      <div class="icon"><i class="fas fa-user-shield"></i></div>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-success">
      <div class="inner"><h3><?= (int)($roleTotals['doctor'] ?? 0) ?></h3><p>Doctors</p></div>
      <div class="icon"><i class="fas fa-user-md"></i></div>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-warning">
      <div class="inner"><h3><?= (int)($roleTotals['patient'] ?? 0) ?></h3><p>Patients</p></div>
      <div class="icon"><i class="fas fa-users"></i></div>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-secondary">
      <div class="inner"><h3><?= (int)$apptToday ?></h3><p>Appointments today</p></div>
      <div class="icon"><i class="fas fa-calendar-day"></i></div>
    </div>
  </div>
</div>

<div class="row">
  <?php foreach ($weekByStatus as $w) : ?>
    <div class="col-lg-3 col-6">
      <div class="small-box bg-<?= e(badge_class_for_status($w['status'])) ?>">
        <div class="inner"><h3><?= (int)$w['total'] ?></h3><p>This week: <?= e($w['status']) ?></p></div>
        <div class="icon"><i class="fas fa-calendar"></i></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header"><h3 class="card-title">Recent appointments</h3></div>
  <div class="card-body p-0">
    <table class="table">
      <thead><tr><th>When</th><th>Patient</th><th>Doctor</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($recent as $r) : ?>
        <tr>
          <td><?= e($r['appt_date']) ?> <?= e(formatTime($r['appt_time'])) ?></td>
          <td><?= e($r['patient_name']) ?></td>
          <td><?= e($r['doctor_name']) ?></td>
          <td><span class="badge badge-<?= e(badge_class_for_status($r['status'])) ?>"><?= e($r['status']) ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
require __DIR__ . '/../partials/content_end.php';
require __DIR__ . '/../partials/footer.php';
