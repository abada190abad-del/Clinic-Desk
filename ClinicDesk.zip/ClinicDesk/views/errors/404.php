<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>404</title>
  <link rel="stylesheet" href="<?= e(ADMINLTE_WEB) ?>/dist/css/adminlte.min.css">
</head>
<body class="hold-transition">
<div class="p-5">
  <h1>404 — Not found</h1>
  <p><a href="index.php?page=dashboard">Back to dashboard</a></p>
</div>
</body>
</html>
