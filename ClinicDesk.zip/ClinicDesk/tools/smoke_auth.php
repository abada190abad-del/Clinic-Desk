<?php
$_GET['page'] = 'auth';
$_GET['action'] = 'login';
$_SERVER['REQUEST_METHOD'] = 'GET';
require dirname(__DIR__) . DIRECTORY_SEPARATOR . 'index.php';
