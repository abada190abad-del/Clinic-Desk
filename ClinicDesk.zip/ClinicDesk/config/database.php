<?php
// Local default — do not commit real passwords (see .gitignore).

define('DB_HOST', 'localhost');
define('DB_NAME', 'clinicdesk_db');
define('DB_USER', 'root');
define('DB_PASS', '');
