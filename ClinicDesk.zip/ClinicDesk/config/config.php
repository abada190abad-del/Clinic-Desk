<?php

define('APP_NAME', 'ClinicDesk');
define('BASE_PATH', dirname(__DIR__));

define('ITEMS_PER_PAGE', 10);

define('MAX_AVATAR_BYTES', 1024 * 1024);
define('MAX_DOCTOR_PHOTO_BYTES', 1024 * 1024);
define('MAX_PRESCRIPTION_BYTES', 3 * 1024 * 1024);

define('ADMINLTE_WEB', 'public/assets/adminlte');
define('UPLOAD_WEB', 'public/uploads');

// Optional — leave empty to use rule-based booking without OpenAI
define('OPENAI_API_KEY', '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');
define('OPENAI_MODEL', 'gpt-4o-mini');

ini_set('display_errors', '0');
error_reporting(E_ALL);
