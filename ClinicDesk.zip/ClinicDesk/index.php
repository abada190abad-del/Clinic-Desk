<?php

session_start();

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/core/helpers.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/Auth.php';
require_once __DIR__ . '/core/CSRF.php';
require_once __DIR__ . '/core/Paginator.php';

require_once __DIR__ . '/models/BaseModel.php';
require_once __DIR__ . '/models/UserModel.php';
require_once __DIR__ . '/models/SpecializationModel.php';
require_once __DIR__ . '/models/DoctorModel.php';
require_once __DIR__ . '/models/AppointmentModel.php';
require_once __DIR__ . '/models/PrescriptionModel.php';

require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/DashboardController.php';
require_once __DIR__ . '/controllers/UserController.php';
require_once __DIR__ . '/controllers/DoctorController.php';
require_once __DIR__ . '/controllers/AppointmentController.php';
require_once __DIR__ . '/controllers/PrescriptionController.php';
require_once __DIR__ . '/controllers/ReportController.php';
require_once __DIR__ . '/controllers/HomeController.php';
require_once __DIR__ . '/controllers/ChatbotController.php';

$rawPage = isset($_GET['page']) ? sanitize((string) $_GET['page']) : '';
$page = $rawPage !== '' ? $rawPage : 'home';
$action = isset($_GET['action']) ? sanitize((string) $_GET['action']) : 'index';

$guestPages = ['auth', 'home', 'chatbot'];
if (!Auth::check() && !in_array($page, $guestPages, true)) {
    redirect('index.php?page=auth&action=login');
}

if (Auth::check()) {
    $cu = Auth::currentUser();
    if ($cu !== null && (int) ($cu['first_login'] ?? 0) === 1) {
        $allowed = ($page === 'auth' && ($action === 'change_password' || $action === 'logout'));
        if (!$allowed) {
            redirect('index.php?page=auth&action=change_password');
        }
    }
}

if ($page === 'home') {
    $c = new HomeController();
    $c->index();
    exit;
}

if ($page === 'chatbot') {
    $c = new ChatbotController();
    $c->handle($action);
    exit;
}

if ($page === 'auth') {
    $c = new AuthController();
    $c->handle($action);
    exit;
}

if ($page === 'errors') {
    if ($action === 'forbidden') {
        http_response_code(403);
        require __DIR__ . '/views/errors/403.php';
        exit;
    }
    if ($action === 'notfound') {
        http_response_code(404);
        require __DIR__ . '/views/errors/404.php';
        exit;
    }
    http_response_code(404);
    require __DIR__ . '/views/errors/404.php';
    exit;
}

if ($page === 'dashboard') {
    $c = new DashboardController();
    $c->index();
    exit;
}

if ($page === 'users') {
    $c = new UserController();
    $c->handle($action);
    exit;
}

if ($page === 'specializations') {
    Auth::requireRole('admin');
    $c = new UserController();
    $c->specializations($action);
    exit;
}

if ($page === 'doctors') {
    $c = new DoctorController();
    $c->handle($action);
    exit;
}

if ($page === 'appointments') {
    $c = new AppointmentController();
    $c->handle($action);
    exit;
}

if ($page === 'prescriptions') {
    $c = new PrescriptionController();
    $c->handle($action);
    exit;
}

if ($page === 'reports') {
    $c = new ReportController();
    $c->handle($action);
    exit;
}

if ($page === 'profile') {
    $c = new UserController();
    $c->me($action);
    exit;
}

http_response_code(404);
require __DIR__ . '/views/errors/404.php';
exit;
